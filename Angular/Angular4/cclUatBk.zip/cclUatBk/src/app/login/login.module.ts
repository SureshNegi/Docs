import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from 'src/app/login/login-vw.component';
import { LoginRoutingModule } from 'src/app/login/login-routing.module';
import { LoginHeaderComponent } from 'src/app/login/components/header/header.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FooterComponent } from './components/footer/footer.component';



@NgModule({
  declarations: [LoginComponent, LoginHeaderComponent, FooterComponent],
  imports: [
    CommonModule, LoginRoutingModule, SharedModule
  ],
  exports: [LoginComponent]
})
export class LoginModule { }
