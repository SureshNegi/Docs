import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from 'src/app/core/auth.service';
import { LoginAPIResponse, EnumAPIResponseStatus } from '../core/api-response.model';
import { Router, CanActivate } from '@angular/router';

@Component({
  selector: 'app-login-vw',
  templateUrl: './login-vw.component.html',
  //styleUrls: ['./login-vw.component.scss']
})
export class LoginComponent implements OnInit {
  lgnForm: FormGroup;
  submitted = false;
  apiErrorMessage: string;
  formObj = {
    name: ['', Validators.required],
    password: ['', Validators.required]
  };
  constructor(public router: Router, private fb: FormBuilder, private authService: AuthService) {
    this.createForm();
  }
  get f() {
    return this.lgnForm.controls;
  }
  hideAPIError() {
    this.apiErrorMessage = '';
  }
  createForm() {
    this.lgnForm = this.fb.group(this.formObj);
  }
  ngOnInit() {
  }
  onSubmit() {
    this.submitted = true;
    if (this.lgnForm.valid) {
      // this.lgnForm.controls.get()
      // this.authService.employeeLogin(){
      const userName = this.lgnForm.controls['name'].value;
      const passwd = this.lgnForm.controls['password'].value;
      console.log(userName);
      this.authService.employeeLogin(userName, passwd).subscribe((apiResp: LoginAPIResponse) => {
        if (apiResp.ResponseStatus === EnumAPIResponseStatus.OK) {
          this.router.navigate(['dashboard']);
        } else {
          this.apiErrorMessage = apiResp.AckMessage;
        }
      });
    }
    // this.apiErrorMessage = 'Error : Invalid Login, please try again.';
  }

}
