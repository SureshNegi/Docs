import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardVwComponent } from './dashboard-vw.component';

describe('DashboardVwComponent', () => {
  let component: DashboardVwComponent;
  let fixture: ComponentFixture<DashboardVwComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardVwComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardVwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
