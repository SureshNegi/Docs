import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-g-detail-cell-component',
  templateUrl: './grd-detail-cell-template.component.html',
  // styleUrls: ['./grd-detail-cell-template.component.scss']
  // styles: [`.btn-blue-grey{ background-color: #78909c !important;
  //           color: #fff;
  //           width: 25.15385px;
  //           height: 25.15385px;
  //           border-radius: 50%;
  //           padding: 0;
  //           cursor: pointer;}`]
})
export class DetailCellTemplateComponent {
  @Output() hadleClickEvent = new EventEmitter();
  constructor() { }

  showDetail() {
    this.hadleClickEvent.emit();
  }

}
