import { Component, OnInit, EventEmitter, Output, Input, OnChanges } from '@angular/core';

import * as enums from '../../models/enum';
import { CCLFeedbackItem } from '../../models/feedback';
import { AddFeedbackItemComponent } from '../add-feedback-item/add-feedback-item.component';
import { FeedbaackItemFullVwComponent } from '../feedbaack-item-full-vw/feedbaack-item-full-vw.component';
declare var $: any;

@Component({
  selector: 'app-data-grid',
  templateUrl: './data-grid.component.html',
  // styleUrls: ['./data-grid.component.scss']
})
export class DataGridComponent implements OnInit, OnChanges {
  @Input() columnDefinitions: any[] = [];
  @Input() dataset: any[] = [];
  @Input() grdId = '';
  @Input() availableHeightForGrid = 100;
  angularSilkGrid: any;
  slickGrid: any;
  constructor() { }
  ngOnInit() {
  }
  ngOnChanges() {
    console.log(this.columnDefinitions);
  }
}


