import { Component, OnInit, Output, EventEmitter, HostListener, ViewChild } from '@angular/core';

@Component({
  selector: 'app-all-cclvw-grid',
  templateUrl: './all-cclvw-grid.component.html',
  //styleUrls: ['./all-cclvw-grid.component.scss']
})
export class AllCCLVwGridComponent implements OnInit {
  columnDefinitions = [];
  @ViewChild('grid', { static: true }) gridObj;
  @Output() loadFeedbackDetailsEvent = new EventEmitter();
  cclTypes = ['Enhancement', 'Fix', 'Maintenance'];
  statusOptions = [{ value: '', label: 'All' },
  { value: CCLStaus.Sucessfull, label: 'Sucessful' },
  { value: CCLStaus.UnSucessfull, label: 'Unsucessful' }];
  retestOptions = [{ value: '', label: 'All' }, { value: 'Yes', label: 'Yes' }, { value: 'No', label: 'No' }];
  dataSet: any = [];
  constructor() { }
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    // setTimeout(() => { this.gridObj.scrollHeight = '250px'; }, 1000);
    this.gridObj.scrollHeight = '250px';
  }
  ngOnInit() {
    localStorage.setItem(
      'statedemo-local',
      '{"columnWidths":"250,200,400,250"}'
    );
    this.columnDefinitions = [
      {
        name: 'Application', field: 'appName', sortable: true,  filterable: true, colNo: 1, filter: true
      },
      {
        name: 'Status', field: 'status', sortable: true, filterable: true, colNo: 2, filter: true
      },
      { name: 'CCL#', field: 'cclNo', sortable: true, colNo: 3, width: 50 },
      { id: 'type', name: 'Type', field: 'type', colNo: 4, width: 80 },
      { id: 'cepCode', name: 'CEP Code', field: 'cepCode', colNo: 5 },
      {
        name: 'CCL Description', field: 'desc', sortable: true, minWidth: 350, width: 350, maxWidth: 350, colNo: 6
      },
      { name: 'Date Released', field: 'releasedDate', sortable: true, colNo: 7 },
      {
        name: 'Pending Retest', field: 'pendingRetest', sortable: true, filterable: true, colNo: 8
      },

      { name: 'Feedback Summary', field: 'feedbackSummary', sortable: true, width: 150, colNo: 9, filter: true },
      {
        name: '', field: 'detail', minWidth: 50, width: 50, maxWidth: 50, colNo: 10
      },
    ];
    this.setWidth();
    this.bindGridDatasource();
  }
  setWidth() {
    this.columnDefinitions.forEach(c => {
      c.width = c.width ? c.width : 'auto';
    });
  }
  onRowSelect(e) {
    console.log(e);
    return false;
  }
  showDetails() {
    this.loadFeedbackDetailsEvent.emit();
  }
  bindGridDatasource() {
    for (let i = 0; i < 5; i++) {
      const randomYear = 2000 + Math.floor(Math.random() * 10);
      const randomMonth = Math.floor(Math.random() * 11);
      const randomDay = Math.floor((Math.random() * 28));
      const randomPercent = Math.round(Math.random() * 100);

      this.dataSet[i] = {
        appName: 'App' + i, // again VERY IMPORTANT to fill the "id" with unique values
        status: (i % 2 === 0) ? CCLStaus.Sucessfull : CCLStaus.UnSucessfull,
        cclNo: 100 + i,
        cclLink: `http://teamsites-west.mercer.com/sites/WebCAS_CCL_documents/Shared%20Documents/Specifications/9300-9399/9306`,
        type: this.cclTypes[i > 2 ? 0 : i],
        cepCode: (i < 5 ? 'MSGT01-207-001' : (i >= 5 ? 'MSGT01-307-001' : 'MSGT01-207-001')),
        // tslint:disable-next-line:max-line-length
        desc: `Additional CC Recipients field is retaining value from previous invoice when multiple invoices are created without closing the Billing screen.`,
        effortDriven: (i % 5 === 0),
        releasedDate: '10-MAR-17',
        pendingRetest: (i % 2 === 0 ? 'Yes' : 'No'),
        feedbackSummary: { total: 100, openFeedback: i, openSDR: 10, pendingRequest: 0 }
      };
    }
  }
}
enum CCLStaus {
  Sucessfull = 1,
  UnSucessfull = 2
}
