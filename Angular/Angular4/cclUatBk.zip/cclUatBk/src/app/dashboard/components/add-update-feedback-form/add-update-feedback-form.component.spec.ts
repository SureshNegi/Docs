import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUpdateFeedbackFormComponent } from './add-update-feedback-form.component';

describe('AddUpdateFeedbackFormComponent', () => {
  let component: AddUpdateFeedbackFormComponent;
  let fixture: ComponentFixture<AddUpdateFeedbackFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUpdateFeedbackFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUpdateFeedbackFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
