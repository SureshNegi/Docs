import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as enums from '../../models/enum';
import { CCLFeedbackItem } from '../../models/feedback';
import { AddFeedbackItemComponent } from '../../components/add-feedback-item/add-feedback-item.component';
import { FeedbaackItemFullVwComponent } from '../feedbaack-item-full-vw/feedbaack-item-full-vw.component';

@Component({
  selector: 'app-feedback-items-details',
  templateUrl: './feedback-items-details.component.html',
  // styleUrls: ['./feedback-items-details.component.scss']
})
export class FeedbackItemsComponent implements OnInit {
  @Output() loadMainView = new EventEmitter();
  statusOptions = [{ value: '', label: 'All' },
  { value: enums.CCLStaus.Sucessfull, label: 'Sucessful' },
  { value: enums.CCLStaus.UnSucessfull, label: 'Unsucessful' }];
  columnDefinitions: any[] = [];
  dataset: any[];
  constructor(private modalService: NgbModal) {
  }

  ngOnInit() {
    this.setGridCoumns();
    this.getFeedbackItems();
  }
  showFeedbackItemFullDetail() {
    const modalRef = this.modalService.open(FeedbaackItemFullVwComponent, { centered: true, windowClass: 'full-vw-pop', size: 'xl' }); 
  }
  closeFeedbackDetailView() {
    this.loadMainView.emit();
  }
  addNewFeedback() {
    this.showAddFeedbackPopUp();
  }
  showAddFeedbackPopUp() {
    const modalRef = this.modalService.open(AddFeedbackItemComponent, { centered: true, windowClass: 'confirm-st-pop', size: 'lg' });
    modalRef.result.then((data) => {
      if (data) {
        console.log('add new feedback');
        this.addNewFeedbackItem();
      }
    }, (reason) => {
      // alert('dismiss');
    });
  }
  addNewFeedbackItem() {
    // for (let i = 2; i < 3; i++) {
    const feedbackItem: CCLFeedbackItem = {} as CCLFeedbackItem;
    feedbackItem.id = 9;
    feedbackItem.status = enums.CCLStaus.UnSucessfull;
    feedbackItem.stage = enums.CCLStaus.UnSucessfull;
    feedbackItem.attachement = 'new.jpg';
    feedbackItem.comment = 'this is new item';
  }

  setGridCoumns() {
    this.columnDefinitions = [
      {
        name: 'Status', field: 'status', sortable: true, colNo: 1
      },
      {
        name: 'F/B #', field: 'id', sortable: true, minWidth: 100, width: 100, maxWidth: 100, colNo: 2
      },
      { name: 'Comment', field: 'comment', sortable: true, minWidth: 350, width: 350, maxWidth: 350, colNo: 3 },
      { name: 'File', field: 'attachement', sortable: true, minWidth: 100, width: 100, maxWidth: 100, colNo: 4 },
      {
        name: 'Stage', field: 'stage', sortable: true, colNo: 5
      },
      { name: 'Created', field: 'createdOn', sortable: true, minWidth: 100, width: 100, maxWidth: 100, colNo: 6 },
      { name: 'Last Updated', field: 'lastUpdatedOn', sortable: true, minWidth: 100, width: 100, maxWidth: 100, colNo: 7 },
      { name: 'Updated By', field: 'updatedBy', sortable: true, minWidth: 100, width: 100, maxWidth: 100, colNo: 8 },
      {
        id: 'detail', name: '', field: 'detail', minWidth: 50, width: 50, maxWidth: 50, colNo: 9
      },
    ];
    this.getFeedbackItems();
  }
  getFeedbackItems() {
    this.dataset = [];
    for (let i = 0; i < 2; i++) {
      const feedbackItem: CCLFeedbackItem = {} as CCLFeedbackItem;
      feedbackItem.id = i;
      feedbackItem.status = (i % 2 === 0) ? enums.CCLStaus.Sucessfull : enums.CCLStaus.UnSucessfull;
      feedbackItem.stage = (i % 2 === 0) ? enums.CCLStaus.Sucessfull : enums.CCLStaus.UnSucessfull;
      feedbackItem.attachement = 'demo.jpg';
      feedbackItem.comment = `uat testing test`;
      feedbackItem.createdOn = '24-OCT-19 08:07';
      feedbackItem.lastUpdatedOn = '24-OCT-19 08:07';
      feedbackItem.updatedBy = 'Ronda Walles';
      this.dataset.push(feedbackItem);
    }
  }



  getStatusDropdownlistData() {
    const dropdownList: KeyValue[] = [];
    dropdownList[0] = { value: '', label: 'All' };
    dropdownList.push({ value: enums.CCLStaus.Sucessfull, label: enums.CCLStaus.SucessfullText });
    dropdownList.push({ value: enums.CCLStaus.UnSucessfull, label: enums.CCLStaus.UnSucessfullText });
    return dropdownList;
  }
  getStageDropdownlistData() {
    const dropdownList: KeyValue[] = [];
    dropdownList[0] = { value: '', label: 'All' };
    dropdownList.push({ value: enums.FeedbackStages.PendingMCIS, label: enums.FeedbackStages.PendingMCIStext });
    return dropdownList;
  }
}
class KeyValue {
  value: any;
  label: any;
}


