import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CCLFeedbackItem } from '../../models/feedback';
import * as enums from '../../models/enum';

@Component({
  selector: 'app-add-upd-feedback-form',
  templateUrl: './add-update-feedback-form.component.html',
  // styleUrls: ['./add-update-feedback-form.component.scss']
})
export class AddUpdateFeedbackFormComponent implements OnInit {
  addFeedbackFrm: FormGroup;
  apiErrorMessage: '';
  @Input() mode = 1;
  formGroupCls = 'col-12';
  submitted = false;
  formObj = {
    comment: ['', Validators.required],
    attachement: ['']
  };

  constructor(private fb: FormBuilder, private model: NgbActiveModal) {
    this.createForm();
  }
  ngOnInit() {
    if (+this.mode === 2) {
      this.formGroupCls = 'col-6';
    }
  }
  get f() {
    return this.addFeedbackFrm.controls;
  }
  createForm() {
    this.addFeedbackFrm = this.fb.group(this.formObj);
  }
  showHistoryVw() {
    alert('hi');
  }
  hideAPIError() {
    this.apiErrorMessage = '';
  }
  closePopUp() {

  }
  onSubmit() {

  }
  submitFeedback() {
    this.submitted = true;
    if (this.addFeedbackFrm.valid) {
      const feedback: CCLFeedbackItem = {} as CCLFeedbackItem;
      feedback.attachement = '';
      feedback.comment = this.addFeedbackFrm.controls['comment'].value;
      feedback.stage = 1;
      feedback.status = 1;
      feedback.id = 12;
      this.model.close(feedback);
    }
    // this.apiErrorMessage = 'Error : Invalid Login, please try again.';
  }

}
