import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllCCLVwGridComponent } from './all-cclvw-grid.component';

describe('AllCCLVwGridComponent', () => {
  let component: AllCCLVwGridComponent;
  let fixture: ComponentFixture<AllCCLVwGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllCCLVwGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllCCLVwGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
