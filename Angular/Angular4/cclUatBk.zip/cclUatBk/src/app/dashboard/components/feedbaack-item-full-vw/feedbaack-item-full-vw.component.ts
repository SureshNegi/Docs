import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CCLFeedbackItem } from '../../models/feedback';
import * as enums from '../../models/enum';

@Component({
  selector: 'app-feedbaack-item-full-vw',
  templateUrl: './feedbaack-item-full-vw.component.html',
  // styleUrls: ['./feedbaack-item-full-vw.component.scss']
})
export class FeedbaackItemFullVwComponent implements OnInit {
  @ViewChild('outerMostDiv', null) parentElem: ElementRef;
  historyViewO: any = { columns: [], dataset: [] };
  sdrViewO: any = { columns: [], dataset: [] };
  addFeedbackFrm: FormGroup;
  submitted = false;
  availableHeightForGrid = 0;
  formObj = {
    comment: ['', Validators.required],
    attachement: ['']
  };
  constructor(private fb: FormBuilder, private model: NgbActiveModal) {
    this.createForm();
  }
  ngOnInit() {
    this.setGridCoumns();
    this.setGridDataSource();
    setTimeout(() => {
      this.availableHeightForGrid = (this.parentElem.nativeElement.offsetHeight - 50);
    }, 0);

  }
  get f() {
    return this.addFeedbackFrm.controls;
  }
  createForm() {
    this.addFeedbackFrm = this.fb.group(this.formObj);
  }
  showHistoryVw() {
    alert('hi');
  }
  submitFeedback() {
    this.submitted = true;
    if (this.addFeedbackFrm.valid) {
      const feedback: CCLFeedbackItem = {} as CCLFeedbackItem;
      feedback.attachement = '';
      feedback.comment = this.addFeedbackFrm.controls['comment'].value;
      feedback.stage = 1;
      feedback.status = 1;
      feedback.id = 12;
      this.model.close(feedback);
    }
    // this.apiErrorMessage = 'Error : Invalid Login, please try again.';
  }
  closeModel() {
    this.model.dismiss();
  }
  setGridCoumns() {
    this.historyViewO.columns = [
      {
         name: 'Comment', field: 'comment', sortable: true, minWidth: 500, width: 500
      },
      {  name: 'File', field: 'attachement', sortable: true },
      {
        name: 'Status', field: 'status', sortable: true
      },
      {  name: 'Last Updated', field: 'lastUpdatedOn', sortable: true }
    ];
    this.sdrViewO.columns = [
      {
        id: 'markAs', name: 'Mark as', field: 'markAs', sortable: true
      },
      { id: 'sdrNo', name: 'SDR #', field: 'sdrNo', sortable: true },
      {
        id: 'desc', name: 'Description', field: 'desc', sortable: true
      },
      { id: 'status', name: 'Status', field: 'status', sortable: true }
    ];
  }
  setGridDataSource() {
    for (let i = 0; i < 100; i++) {
      const feedbackItem: CCLFeedbackItem = {} as CCLFeedbackItem;
      feedbackItem.id = i;
      feedbackItem.status = (i % 2 === 0) ? enums.CCLStaus.Sucessfull : enums.CCLStaus.UnSucessfull;
      feedbackItem.stage = (i % 2 === 0) ? enums.CCLStaus.Sucessfull : enums.CCLStaus.UnSucessfull;
      feedbackItem.attachement = 'demo.jpg';
      // tslint:disable-next-line:max-line-length
      feedbackItem.comment = `comments about feedback ` + i;
      this.historyViewO.dataset.push(feedbackItem);
    }
    for (let i = 0; i < 0; i++) {
      const feedbackItem = { id: 0, markAs: '', sdrNo: '', desc: '', status: '' };
      feedbackItem.id = i;
      feedbackItem.markAs = 'markAs';
      feedbackItem.sdrNo = '00';
      feedbackItem.desc = 'demo.jpg';
      feedbackItem.status = `test`;
      this.sdrViewO.dataset.push(feedbackItem);
    }
  }

}
