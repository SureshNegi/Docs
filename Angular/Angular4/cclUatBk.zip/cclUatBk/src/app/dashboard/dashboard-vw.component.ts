import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/core/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard-vw',
  templateUrl: './dashboard-vw.component.html',
  styleUrls: ['./dashboard-vw.component.scss']
})
export class DashboardVwComponent implements OnInit {
  cclView = true;
  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {
  }
  signOut() {
    this.authService.employeeLogout('').subscribe((data) => {
      this.router.navigate(['login']);
    });
  }
  showFeedbackDetailView() {
    this.cclView = false;
  }
  showMainView() {
    this.cclView = true;
  }

}
