import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardVwComponent } from 'src/app/dashboard/dashboard-vw.component';

import { DashboardRoutingModule } from 'src/app/dashboard/dashboard-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { PrimengModuleProvider } from './primeng.module';
import { CCLStatusPipe } from './pipes/status.pipe';
import { HeaderComponent } from 'src/app/dashboard/components/header/header.component';
import { AllCCLVwGridComponent } from 'src/app/dashboard/components/all-cclvw-grid/all-cclvw-grid.component';
import { DetailCellTemplateComponent } from './components/grd-detail-cell-template/grd-detail-cell-template.component';
import { FeedbackItemsComponent } from './components/feedback-items-details/feedback-items-details.component';
import { AddFeedbackItemComponent } from './components/add-feedback-item/add-feedback-item.component';
import { NgbModule, NgbDropdownModule, NgbTooltipModule, NgbModalModule, NgbTabsetModule } from '@ng-bootstrap/ng-bootstrap';
import { AddUpdateFeedbackFormComponent } from './components/add-update-feedback-form/add-update-feedback-form.component';
import { FeedbaackItemFullVwComponent } from './components/feedbaack-item-full-vw/feedbaack-item-full-vw.component';
import { DataGridComponent } from './components/data-grid/data-grid.component';

const bootStratModules = [NgbModule, NgbDropdownModule, NgbTooltipModule, NgbModalModule, NgbTabsetModule];
@NgModule({
  // tslint:disable-next-line:max-line-length
  declarations: [DataGridComponent, FeedbackItemsComponent, FeedbaackItemFullVwComponent, AddUpdateFeedbackFormComponent, CCLStatusPipe, AddFeedbackItemComponent,
    DetailCellTemplateComponent, DashboardVwComponent, HeaderComponent, AllCCLVwGridComponent],
  imports: [SharedModule, CommonModule, DashboardRoutingModule,
    PrimengModuleProvider, bootStratModules
  ],
  exports: [DashboardVwComponent, AddFeedbackItemComponent],
  entryComponents: [AddFeedbackItemComponent, FeedbaackItemFullVwComponent]
})
export class DashboardModule { }
