import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'cclStatus'
})
export class CCLStatusPipe implements PipeTransform {

  transform(value: any): any {
    // tslint:disable-next-line:max-line-length
    return (value === 1) ? 'Sucessfull' : 'Unsucessfull';
  }

}
