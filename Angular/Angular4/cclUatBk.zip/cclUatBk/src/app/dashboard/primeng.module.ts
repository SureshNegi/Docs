import { NgModule } from '@angular/core';
import { TableModule, } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { SharedModule } from 'src/app/shared/shared.module';
@NgModule({
  declarations: [],
  exports: [TableModule, DropdownModule],
  entryComponents: []
})
export class PrimengModuleProvider { }
