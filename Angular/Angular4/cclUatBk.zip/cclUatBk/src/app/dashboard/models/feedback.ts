export interface CCLFeedbackItem {
    status: number;
    id: number;
    comment: string;
    attachement: string;
    stage: number;
    createdOn: string;
    lastUpdatedOn: string;
    updatedBy: string;

}
