export enum CCLStaus {
    Sucessfull = 1,
    UnSucessfull = 2,
    SucessfullText = 'Sucessful',
    UnSucessfullText = 'Unsucessful',
}
export enum FeedbackStages {
    PendingMCIS = 1,
    PendingMCIStext = 'Pending MCIS'
}
