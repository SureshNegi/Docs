import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, mergeMap } from 'rxjs/operators';
import { APIBaseAddress } from './app-config';
import { APINames } from './api-url.config';
import { Observable, of, from } from 'rxjs';
import { delay } from 'rxjs/internal/operators';
import { concatMap } from 'rxjs/internal/operators';
import * as APIRespObj from './api-response.model';
import { CookieService } from 'ngx-cookie-service';
const apiParamPrefix = 'I_JSON';
import { LoaderService } from '../shared/loader.service';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    redirectUrl: string;
    constructor(private loaderService: LoaderService, private httpClient: HttpClient, private cookieService: CookieService) { }
    employeeLogin(uName, pass): Observable<APIRespObj.IAPIResponse> {
        const apiURL = `${APIBaseAddress}${APINames.empLogin}`;
        const paramObj = {
            username: uName, password: pass
        };
        const headers = new HttpHeaders().set('Content-Type', 'application/json').set('Access-Control-Allow-Origin', '*');
        return this.httpClient.post<APIRespObj.IAPIResponse>(apiURL, paramObj, { headers }).pipe(map(apiObj => {
            console.log(apiObj);
            debugger;
            return this.parseLoginAPIResponse(apiObj);
        })
        );
        // this.loaderService.isLoading.next(true);
        // const obj = this.parseLoginAPIResponse(null);
        // const fakeObservable = of(obj).pipe(delay(1000));
        // fakeObservable.subscribe(() => {
        //     this.loaderService.isLoading.next(false);
        // });
        // return fakeObservable;
    }
    employeeLogout(uName): Observable<APIRespObj.IAPIResponse> {
        const apiURL = `${APIBaseAddress}${APINames.empLogin}`;
        const paramObj = {
            LOGIN_IN_OBJ: { USRNAME: uName, PW: uName }
        };
        const paramString = `${apiParamPrefix}=${JSON.stringify(paramObj)}`;
        return this.httpClient.post<APIRespObj.IAPIResponse>(apiURL, paramString).pipe(map(apiObj => {
            this.clearUserSession();
            return this.parseLogoutAPIResponse(apiObj);
        })
        );
    }
    parseLoginAPIResponse(apiObj: any): APIRespObj.IAPIResponse {
        const repObj: APIRespObj.LoginAPIResponse = new APIRespObj.LoginAPIResponse();
        // repObj.ResponseStatus = 4;
        // repObj.AckMessage = 'Invalid Login';
        repObj.Data = { AuthToken: 'abcdefgh', LoginId: 1 } as UserAuthTokenDetail;
        this.saveUserTokeninfo(repObj.Data);
        return repObj;
    }
    parseLogoutAPIResponse(apiObj: any): APIRespObj.IAPIResponse {
        const repObj: APIRespObj.LoginAPIResponse = new APIRespObj.LoginAPIResponse();
        // repObj.ResponseStatus = 4;
        // repObj.AckMessage = 'Invalid Login';
        // repObj.Data = { AuthToken: 'abcdefgh', LoginId: 1 } as UserAuthTokenDetail;
        return repObj;
    }
    isEmpLoggedIn() {
        // const tokenString = localStorage.getItem('userAuthTokenDetail');
        const tokenString = this.getUserTokenInfo();
        const userDetail: UserAuthTokenDetail = tokenString ? JSON.parse(tokenString) : null;
        if (userDetail && userDetail.AuthToken && userDetail.LoginId) {
            return true;
        } else {
            return false;
        }
    }
    saveUserTokeninfo(data: UserAuthTokenDetail) {
        this.cookieService.set('userAuthTokenDetail', JSON.stringify(data));
        localStorage.setItem('userAuthTokenDetail', JSON.stringify(data));
    }
    getUserTokenInfo() {
        return this.cookieService.get('userAuthTokenDetail');
    }
    clearUserSession() {
        localStorage.removeItem('userAuthTokenDetail');
    }
}

class UserAuthTokenDetail {
    AuthToken: string;
    LoginId: number;
}



