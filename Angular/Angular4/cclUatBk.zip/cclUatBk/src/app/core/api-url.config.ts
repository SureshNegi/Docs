export const APINames = {
    lookupCEPCode: 'te_html5_htp_pkg.lookupCEPCode',
    loadCEPCodeDetails: 'te_html5_htp_pkg.loadCEPCodeDetails',
    empLogin: 'api/login',
    retrieveInitialData: 'te_html5_htp_pkg.retrieveInitialData',
    loadRevenueMonths: 'te_html5_htp_pkg.loadRevenueMonths'
};
