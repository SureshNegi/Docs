import { NgModule, ModuleWithProviders } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from 'src/app/core/auth.service';
import { CookieService } from 'ngx-cookie-service';

@NgModule({
  imports: [
    HttpClientModule
  ],
  declarations: [],
  providers: [
    AuthService,
    CookieService
  ],
  exports: []
})
export class CoreModule {
}
