export interface IAPIResponse {
    ResponseStatus: EnumAPIResponseStatus;
    AckMessage: string;
    Data: any;
}
export enum EnumAPIResponseStatus {
    OK = 0,
    Error = 1,
    InvalidSession = 2,
    LogginFail = 3,
}

export class LoginAPIResponse implements IAPIResponse {
    ResponseStatus: EnumAPIResponseStatus;
    AckMessage: string;
    Data: {
        AuthToken: string; LoginId: number;
    };
    constructor() {
        this.AckMessage = '';
        this.ResponseStatus = EnumAPIResponseStatus.OK;
    }
}
