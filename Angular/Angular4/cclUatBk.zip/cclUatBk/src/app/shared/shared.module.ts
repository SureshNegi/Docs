import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { LoaderInterceptor } from '../core/loader.interceptor';
// import { LoadersComponent } from './loaders/loaders.component';
// import { NgbModule, NgbDropdownModule, NgbTooltipModule, NgbModalModule, NgbTabsetModule } from '@ng-bootstrap/ng-bootstrap';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';
import { LoaderService } from './loader.service';
import { LoaderComponent } from './components/loaders/loaders.component';
@NgModule({
  declarations:[LoaderComponent],
  imports: [
    // tslint:disable-next-line:max-line-length
    FormsModule, CommonModule, ReactiveFormsModule
  ], exports: [FormsModule, ReactiveFormsModule,LoaderComponent]
  , providers: [LoaderService, { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }]

})
export class SharedModule { }
