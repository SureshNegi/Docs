import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, } from 'rxjs/operators';
import { APIBaseAddress } from '../global/app-config';
import { APINames } from '../global/api-url.config';
const apiParamPrefix = 'I_JSON';

@Injectable()
export class EmpService {
    constructor(private httpClient: HttpClient) { }
    retrieveInitialData(empId, sessKey) {
        const apiURL = `${APIBaseAddress}${APINames.retrieveInitialData}`;
        const data = { RETINIT_IN_OBJ: { EMPLID: empId } };
        const paramObj = { 'I_JSON': JSON.stringify(data) };
        const httpHeaders: HttpHeaders = new HttpHeaders().set('content-type', 'text/plain').set('authorization', sessKey);
        return this.httpClient.get<any>(apiURL, { params: paramObj, headers: httpHeaders }).pipe(
            map(resp => {
                console.log();
                return resp;
            }),
            catchError(error => {
                return null;
                // throwError(error); // From 'rxjs'
            })
        );
    }
}



