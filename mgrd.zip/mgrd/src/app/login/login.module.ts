import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from 'src/app/login/components/app-login/login.component';
import { LoginRoutingModule } from 'src/app/login/login-routing.module';
import { DesktopLoginComponent } from './components/desktop-login/desktop-login.component';
import { EmpService } from 'src/services/emp.service';

@NgModule({
  declarations: [LoginComponent, DesktopLoginComponent],
  imports: [
    CommonModule, LoginRoutingModule
  ],
  exports: [LoginComponent],
  providers: [EmpService]
})
export class LoginModule { }