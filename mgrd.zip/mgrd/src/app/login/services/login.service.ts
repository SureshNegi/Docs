import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, mergeMap } from 'rxjs/operators';
import { APIBaseAddress } from '../../../global/app-config';
import { APINames } from '../../../global/api-url.config';
import { EmpService } from 'src/services/emp.service';
import { Observable } from 'rxjs';
const apiParamPrefix = 'I_JSON';

@Injectable()
export class LoginService {
    constructor(private httpClient: HttpClient, private empService: EmpService) { }
    employeeLogin(uName, pass, clType, apVer, uAgent) {
        const apiURL = `${APIBaseAddress}${APINames.empLogin}`;
        const paramObj = {
            LOGIN_IN_OBJ: { USRNAME: uName, PW: pass, CLITYP: clType, APPVER: apVer, UAGENT: uAgent }
        };
        const paramString = `${apiParamPrefix}=${JSON.stringify(paramObj)}`;
        return this.httpClient.post<any>(apiURL, paramString).pipe(
            mergeMap(param => this.empService.retrieveInitialData(param.LOGIN_OUT_OBJ.EMPLID, param.LOGIN_OUT_OBJ.SESKEY)));
    }
    getInitialData(empId, sessionKey) {
        // this.empService.retrieveInitialData(empId, sessionKey);

    }
}



