import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainComponent } from './components/main-content-view/main.component';
import { DashboardViewComponent } from './components/dashboard-view/dashboard-view.component';
import { DashboardRoutingModule } from 'src/app/dashboard-module/dashboard-routing.module.';
import { HeaderComponent } from './components/header-view/header.component';

@NgModule({
  declarations: [MainComponent, DashboardViewComponent, HeaderComponent],
  imports: [
    CommonModule, DashboardRoutingModule
  ]
})
export class DashboardModule { }
