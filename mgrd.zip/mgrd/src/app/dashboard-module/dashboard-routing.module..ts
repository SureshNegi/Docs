import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './components/main-content-view/main.component';
import { DashboardViewComponent } from './components/dashboard-view/dashboard-view.component';


const loginRoutes: Routes = [
    {
        path: '',
        component: DashboardViewComponent
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(loginRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class DashboardRoutingModule { }
