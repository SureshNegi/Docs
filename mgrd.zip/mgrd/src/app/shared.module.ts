import { NgModule } from '@angular/core';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { MyTimeGridModule } from 'src/app/my-time-grid/my-time-grid.module';
import { HttpClientModule } from '@angular/common/http';
import { CEPCodeService } from '../services/cepcode.service';



@NgModule({
    declarations: [],
    imports: [
        AngularFontAwesomeModule,
        MyTimeGridModule,
        HttpClientModule
    ],
    providers: [CEPCodeService],
    bootstrap: [],
    exports: [MyTimeGridModule, AngularFontAwesomeModule]
})
export class AppSharedModule { }
