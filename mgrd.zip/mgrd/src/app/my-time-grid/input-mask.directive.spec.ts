import { InputMaskDirective } from './input-mask.directive';

describe('InputMaskDirective', () => {
  it('should create an instance', () => {
    const directive = new InputMaskDirective();
    expect(directive).toBeTruthy();
  });
});
