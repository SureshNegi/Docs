import { Component, OnInit } from '@angular/core';
import {
  Column, GridOption, Editors, FieldType, Formatters, Grouping, Sorters,
  Aggregators, GroupTotalFormatters, AngularGridInstance, SortDirectionNumber
} from 'angular-slickgrid';
import { HttpClient } from '@angular/common/http';
import { CustomInputEditor } from 'src/app/my-time-grid/CustomInputEditorExample';
import { CEPCodeService } from 'src/services/cepcode.service';
const empId = 249503;
const cmpId = 96;


@Component({
  selector: 'app-data-grid',
  templateUrl: './data-grid.component.html',
  styleUrls: ['./data-grid.component.css'],
  // providers: [CEPCodeService]
})
export class DataGridComponent implements OnInit {
  columnDefinitions: Column[] = [];
  gridOptions: GridOption = {};
  dataset: SlickGridData[] = [];
  dataviewObj: any;
  angularGrid: any;
  gridObj: any;
  sessionKey = '91C8EBE0EAD5861A4F6D0ED5EB3E17F56AB00784CE15FF334A8709D17050662A';
  showInlineCEPSrchResult = false;
  inlineEditCEPInput = '';
  gridRowToInlineUpdate: TESlickGridData;
  constructor(private http: HttpClient, private cepService: CEPCodeService) { }
  groupByCEPCode() {
    this.dataviewObj.setGrouping({
      getter: 'CEPCode',
      formatter: (g) => `CEP Code:  ${g.value} <span style='color:green'>(${g.count} items)</span>`,
      comparer: (a, b) => Sorters.numeric(a.value, b.value, SortDirectionNumber.asc),
      aggregateCollapsed: false,
      lazyTotalsCalculation: true
    } as Grouping);
  }
  angularGridReady(angularGrid: AngularGridInstance) {
    this.angularGrid = angularGrid;
    this.gridObj = angularGrid.slickGrid;
    this.dataviewObj = angularGrid.dataView;

    // display a spinner while downloading
    // this.exportBeforeSub = this.angularGrid.exportService.onGridBeforeExportToFile.subscribe(() => this.processing = true);
    // this.exportAfterSub = this.angularGrid.exportService.onGridAfterExportToFile.subscribe(() => this.processing = false);
    setTimeout(() => {
      this.groupByCEPCode();
    }, 2000);

  }
  validateCompanyCode(value: string): boolean {
    const isValidValue = /^[a-z]+$/i.test(value);
    return (value.length === 6 && isValidValue) ? true : false;
  }
  validateEngagementCode(value: string): boolean {
    const isValidValue = /^[0-9]+$/i.test(value);
    return (value.length === 3 && isValidValue) ? true : false;
  }
  validateProjectCode(value: string): boolean {
    const isValidValue = /^[0-9]+$/i.test(value);
    return (value.length === 3 && isValidValue) ? true : false;
  }
  validateCode(value: string) {
    const arr = value.split('-');

    return this.validateCompanyCode(arr[0]) && this.validateEngagementCode(arr[1]) && this.validateProjectCode(arr[2]);
  }
  inlineCEPEditOnSelect(value) {

  }
  onKey(value) {
    console.log(value);
    if (this.validateCode(value)) {
      this.cepService.lookupCEPCode(empId, 'DEVSEL-100-009', cmpId, this.sessionKey).subscribe((resp) => {
        resp.LOOKCEP_OUT_OBJ.CEP_ARR = resp.LOOKCEP_OUT_OBJ.CEP_ARR.filter((item) => {
          return +item.CLIEID !== 0;
        });
        const cepObj = resp.LOOKCEP_OUT_OBJ.CEP_ARR[0];
        this.cepService.loadCEPDetail(cepObj.CLIEID, cepObj.ENGID, cepObj.PRJID, this.sessionKey).subscribe((resp2) => {
          console.log(resp2);
          this.showInlineCEPSrchResult = true;
        });
      });
    } else {
      this.showInlineCEPSrchResult = false;
    }
  }
  setGrouping() {
    this.dataviewObj.setGrouping({
      getter: 'duration',  // the column `field` to group by
      formatter: (g) => {
        // (required) what will be displayed on top of each group
        return `Duration:  ${g.value} <span style="color:green">(${g.count} items)</span>`;
      },
      comparer: (a, b) => {
        // (optional) comparer is helpful to sort the grouped data
        // code below will sort the grouped value in ascending order
        return Sorters.numeric(a.value, b.value, SortDirectionNumber.asc);
      },
      // aggregators: [
      //   // (required), what aggregators (accumulator) to use and on which field to do so
      //   new Aggregators.Avg('percentComplete'),
      //   new Aggregators.Sum('cost')
      // ],
      aggregateCollapsed: false,  // (optional), do we want our aggregator to be collapsed?
      lazyTotalsCalculation: true // (optional), do we want to lazily calculate the totals? True is commonly used
    });
  }
  ngOnInit() {
    this.columnDefinitions = [
      // { id: 'title', name: 'Title', field: 'TEId', sortable: true },
      // { id: 'duration', name: 'Duration (days)', field: 'duration', sortable: true },
      // { id: '%', name: '% Complete', field: 'percentComplete', sortable: true },
      // { id: 'start', name: 'Start', field: 'start' },
      // { id: 'finish', name: 'Finish', field: 'finish' },
      // { id: 'effort-driven', name: 'Effort Driven', field: 'effortDriven', sortable: true }
      // {
      //   id: 'duration', name: 'Duration', field: 'duration',
      //   type: FieldType.number,
      //   groupTotalsFormatter: GroupTotalFormatters.sumTotals,
      //   params: { groupFormatterPrefix: 'Total: ' },
      //   editor: {
      //     // tslint:disable-next-line:max-line-length
      //     collectionAsync: this.http.get<{ value: string; label: string; }[]>('https://ghiscoding.github.io/angular-slickgrid-bs4-demo/assets/data/collection_100_numbers.json'),
      //     model: Editors.multipleSelect,
      //   }
      // },
      { id: 'TEId', name: 'TEId', field: 'TEId', sortable: true, formatter: Formatters.editIcon },
      {
        type: FieldType.number,
        id: 'CEPCode', name: 'CEP Code', field: 'CEPCode', sortable: true,
        // editor: { model: Editors.text, placeholder: 'CEP Code', outputType: FieldType.dateIso },
        editor: {
          model: CustomInputEditor, placeholder: 'CEP Code' // reference your custom editor class
        },
        groupTotalsFormatter: GroupTotalFormatters.sumTotals,
        params: {
          groupFormatterPrefix: 'Total: '
        }
      },
      { id: 'Time', name: 'Time', field: 'Time', sortable: true, editor: { model: Editors.float } },
      { id: 'Date', name: 'Date', field: 'Date' },
      { id: 'Desc', name: 'Desc', editor: { model: Editors.longText }, field: 'Desc', type: FieldType.string, }
    ];
    this.gridOptions = {
      enableAutoResize: true,       // true by default
      enableCellNavigation: true,
      autoEdit: false,
      enableRowSelection: true,
      // enableRowDetailView:true,
      editable: true,
      enableGrouping: true
    };

    // fill the dataset with your data
    // tslint:disable-next-line:max-line-length
    // VERY IMPORTANT, Angular-Slickgrid uses Slickgrid DataView which REQUIRES a unique "id" and it has to be lowercase "id" and be part of the dataset
    this.dataset = [];

    // for demo purpose, let's mock a 1000 lines of data
    for (let i = 0; i < 10; i++) {
      const randomYear = 2000 + Math.floor(Math.random() * 10);
      const randomMonth = Math.floor(Math.random() * 11);
      const randomDay = Math.floor((Math.random() * 28));
      const randomPercent = Math.round(Math.random() * 100);
      let clientName = 'DEVSEL-100-009';
      if (i > 20 && i < 50) {
        clientName = 'DEVSEL-000-000';
      } else if (i > 50) {
        clientName = 'DEVSEL-000-010';
      }
      const teObj = new TESlickGridData();
      teObj.CEPCode = `${clientName}`;
      teObj.id = i;
      teObj.TEId = i;
      teObj.Time = Math.round(Math.random() * 100) + '';
      teObj.Date = `${randomMonth}/${randomDay}/${randomYear}`;
      teObj.Desc = `${randomMonth}/${randomDay}/${randomYear}`;
      teObj.isSubmit = (i % 2 == 1) ? true : false;
      this.dataset[i] = teObj;
      // {
      //   duration: i,
      //   id: i, //do not remove this unique field
      //   TEId: i, // again VERY IMPORTANT to fill the "id" with unique values
      //   CEPCode: `${clientName}`,
      //   Time: Math.round(Math.random() * 100) + '',
      //   Date: `${randomMonth}/${randomDay}/${randomYear}`,
      //   Desc: `${randomMonth}/${randomDay}/${randomYear}`,
      //   isSubmit: (i % 2 == 1) ? true : false
      // };
    }
  }
  verifyCellIsEditableBeforeEditing(e, args): boolean {
    const result = !args.item.isSubmit;
    if (this.checkIsRowChanged(args.item)) {
      console.log('save row...');
    }
    if (result) {
      this.gridRowToInlineUpdate = JSON.parse(JSON.stringify(args.item));
      this.gridOptions.autoEdit = true;
      // https://github.com/ghiscoding/Angular-Slickgrid/wiki/Grid-&-DataView-Events
      this.gridObj.setOptions({ autoEdit: true });
    }
    return result;

    // your logic here should return true/false if it's editable or not
    // args contains the dataContext and other Slickgrid arguments
  }

  onCellClicked(e, args): boolean {
    // https://github.com/ghiscoding/Angular-Slickgrid/blob/master/src/app/modules/angular-slickgrid/services/grid.service.ts
    // this.gridObj.setSelectedRow(args.row);
    const item = args.grid.getDataItem(args.row);
    const isRowEditable = !item.isSubmit;
    return isRowEditable;
    // your logic here should return true/false if it's editable or not
    // args contains the dataContext and other Slickgrid arguments
  }
  // https://github.com/ghiscoding/Angular-Slickgrid/wiki/Editors#event-through-slick-grid-object
  onCellChanged(e, args) {
    // args.grid.invalidateRow(args.row);
    // const row = this.dataviewObj.getItem(args.row);
    if (!this.validateCode(args.item.CEPCode)) {
      // grid.invalidateRow(args.row);
      const row = this.dataviewObj.getItem(args.row);
      args.item.CEPCode = this.gridRowToInlineUpdate.CEPCode;
    } else {
      if (this.checkIsRowChanged(args.item)) {
        console.log('save row...');
      }
    }
    // this.angularGrid.resizerService.resizeGrid(10);
  }

  checkIsRowChanged(currentRowActive) {
    if (this.gridRowToInlineUpdate && currentRowActive.id !== this.gridRowToInlineUpdate.id) {
      return true;
    }
    return false;
  }

  onAfterEditCell(e, args): boolean {

    return true;
    // your logic here should return true/false if it's editable or not
    // args contains the dataContext and other Slickgrid arguments
  }
}

interface TE {
  TEId: number;
  CEPCode: string;
  Time: string;
  Date: string;
  Desc: string;
  isSubmit: boolean;
}

interface NonICTE extends TE {
  TEId: number;
  CEPCode: string;
  Time: string;
  Date: string;
  Desc: string;
  isSubmit: boolean;
}
interface ICTE extends TE {
  ICID: number;
  ICDesc: string;
}
interface SlickGridData extends TE {
  id: number; // unique id field is required by slick grid
}

class TESlickGridData implements NonICTE, ICTE, SlickGridData {
  id: number; // unique id field is required by slick grid
  TEId: number;
  CEPCode: string;
  Time: string;
  Date: string;
  Desc: string;
  isSubmit: boolean;
  ICID: number;
  ICDesc: string;
}
