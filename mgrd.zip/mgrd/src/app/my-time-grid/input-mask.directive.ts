// https://github.com/M-Ulyanov/ng2-inputmask/issues/7

import { Directive, ElementRef } from '@angular/core';
import Inputmask from 'inputmask';
const cepCodeMask = 'cep-mask';
@Directive({
  selector: '[cep-mask]'
})
export class InputCEPCodeMaskDirective {

  constructor(private element: ElementRef) {
    this.setInputMask(element);
  }

  private setInputMask(element: ElementRef) {
    // Get the value of the mask attribute
    const mask = element.nativeElement.getAttribute(cepCodeMask);

    if (mask) {
      // Set the input mask and then mask the element the directive was used on
      Inputmask({ 'mask': mask }).mask(element);
  }
}

}
