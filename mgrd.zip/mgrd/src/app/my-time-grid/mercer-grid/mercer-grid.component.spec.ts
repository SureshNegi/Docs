import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MercerGridComponent } from './mercer-grid.component';

describe('MercerGridComponent', () => {
  let component: MercerGridComponent;
  let fixture: ComponentFixture<MercerGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MercerGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MercerGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
