import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-mercer-grid',
  templateUrl: './mercer-grid.component.html',
  styleUrls: ['./mercer-grid.component.css']
})
export class MercerGridComponent implements OnInit {
  constructor() { }
  @Input() columnDefs: any;
  @Input() rowData: any;
  @Input() noDataMsg = 'No record to display';
  @Output() eAfterCellEdit: EventEmitter<any> = new EventEmitter();
  dataBackup: any;
  @Input() gConfig = { enableFilter: false, headerHeight: 32, filterHeight: 20, rowHeight: 28, headerContHeight: 32 };
  fields = [];

  ngOnInit() {
    this.gConfig.enableFilter = true;
    // tslint:disable-next-line:max-line-length
    this.gConfig.headerContHeight = this.gConfig.enableFilter ? (2 * this.gConfig.headerHeight + this.gConfig.filterHeight) : this.gConfig.headerContHeight;

    this.dataBackup = this.rowData;
  }
  sortData(byColumn) {
    this.rowData = this.rowData.sort((n1, n2) => n2[byColumn.field] - n1[byColumn.field]);
  }
  filterData(filterObj) {
    console.log(this.dataBackup.length);
    this.rowData = this.dataBackup.filter((d) => {
      // tslint:disable-next-line:forin
      for (let key in filterObj) {
        console.log(key);
        const matched = (d[key].toString().toLowerCase().includes(filterObj[key].toString().toLowerCase()));
        if (!matched) { return false; }
      }
      return true;
    });
  }
  onScroll(event, gridHeader, gridBody) {
    console.log(event.target.scrollLeft);
    gridBody.scrollLeft = event.target.scrollLeft;
    gridHeader.scrollLeft = event.target.scrollLeft;
  }
  getGrdBodyHeight() {
    return this.gConfig.rowHeight * this.rowData.length;
  }
  saveRow() {
  }
  afterCellEdit(e) {
    this.eAfterCellEdit.emit(e);
  }
}
