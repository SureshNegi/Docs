/*inline edting
https://www.ag-grid.com/javascript-grid-cell-editing/
*/
import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-sn-grd-body-vw',
  templateUrl: './grid-body-vw.component.html',
  styleUrls: ['./grid-body-vw.component.css']
})
export class GridBodyVwComponent implements OnInit, OnChanges {
  @Input() data: any;
  @Input() noDataMsg = 'No record to display';
  @Input() gCongid = { rowHeight: 28 };
  @Output() eSaveRow: EventEmitter<any> = new EventEmitter();
  @Output() eAfterCellEdit: EventEmitter<any> = new EventEmitter();
  testData = 1;
  htmlData: any = 'val';
  inlineEditTemplate: any = `<div class="sn-input-wrapper" role="presentation" *ngIf>
                        <input (keypress)="handleNavigationKey($event)" class="sn-cell-edit-input" type="text"></div>`;
  fields = [];
  constructor(private sanitizer: DomSanitizer) { }

  ngOnInit() {
    this.fields = ['make', 'model', 'hrs'];
    // this.inlineEditTemplate = this.sanitizer.bypassSecurityTrustHtml(this.inlineEditTemplate);
    // this.htmlData = this.sanitizer.bypassSecurityTrustHtml(this.htmlData);
  }
  ngOnChanges() {
    console.log('OnChanges');
  }
  onRowFocus() {
    console.log('onRowFocus');
  }
  onCellDoubleClick(element: HTMLElement, editCtrl) {
    console.log(editCtrl);
    element.innerHTML = this.inlineEditTemplate;
    element.classList.remove('sn-cell-not-inline-editing');
    element.classList.add('sn-cell-inline-editing');
  }
  getGrdBodyHeight() {
    return this.gCongid.rowHeight * this.data.length;
  }
  rowCellFocus(element: HTMLElement) {
    element.classList.add('sn-cell-focus');
  }
  rowCellFocusOut(element: HTMLElement, oldValue: string) {

    element.classList.remove('sn-cell-focus');
    // element.innerHTML = oldValue;
  }
  afterCellEdit(e) {
    this.setRowFieldValueTo(e.rowNo, e.field, e.newVal);
    this.eAfterCellEdit.emit(e);
  }
  setRowFieldValueTo(rNo, field, value) {
    this.data.forEach(r => {
      if (r.rowId === rNo) {
        r[field] = value;
      }
    });
  }
  saveRow() {
    this.eSaveRow.emit();
  }
  handleNavigationKey(event) {
    console.log(event, event.keyCode, event.keyIdentifier);
  }
}
