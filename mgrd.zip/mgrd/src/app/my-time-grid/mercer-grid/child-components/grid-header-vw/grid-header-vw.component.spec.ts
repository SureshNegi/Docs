import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GridHeaderVwComponent } from './grid-header-vw.component';

describe('GridHeaderVwComponent', () => {
  let component: GridHeaderVwComponent;
  let fixture: ComponentFixture<GridHeaderVwComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GridHeaderVwComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridHeaderVwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
