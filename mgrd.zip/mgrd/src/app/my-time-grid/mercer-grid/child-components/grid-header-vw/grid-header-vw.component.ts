import { Component, OnInit, Output, Input, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-sn-grid-header-vw',
  templateUrl: './grid-header-vw.component.html',
  styleUrls: ['./grid-header-vw.component.css']
})
export class GridHeaderVwComponent implements OnInit {
  @Input() columnDefs: any;
  @Input() headerHeight = 32;
  @Output() eTriggerSort: EventEmitter<any> = new EventEmitter();
  @Output() eTriggerSearch: EventEmitter<any> = new EventEmitter();
  @Output() eTriggerColMenu: EventEmitter<any> = new EventEmitter();
  filterObj: any = {};
  menuObj: any = {};
  cellWidth = 200;
  constructor() { }

  ngOnInit() {
    // this.columnDefs.forEach((c) => {
    //   this.filterObj[c.field] = '';
    // });
  }
  onSort(c) {
    this.columnDefs.forEach(r => {
      if (r.field !== c.field) { (r.sortDir = 0); }
    });
    c.sortDir = (c.sortDir === 0) ? 1 : (c.sortDir === 1 ? 2 : 1);
    this.eTriggerSort.emit(c);
  }
  onSearchChange(searchString, searchedCol) {
    this.filterObj[searchedCol.field] = searchString;
    this.eTriggerSearch.emit(this.filterObj);
  }
  showFilterMenu(column) {
    this.eTriggerColMenu.emit(this.filterObj);
    // this.menuObj.showFilterMenu = true;
  }

}
