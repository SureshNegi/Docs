import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GridColumnMenuVwComponent } from './grid-column-menu-vw.component';

describe('GridColumnMenuVwComponent', () => {
  let component: GridColumnMenuVwComponent;
  let fixture: ComponentFixture<GridColumnMenuVwComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GridColumnMenuVwComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridColumnMenuVwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
