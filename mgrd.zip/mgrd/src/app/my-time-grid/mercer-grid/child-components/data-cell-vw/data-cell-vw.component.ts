/*https://stackblitz.com/github/ramin-ahmadi/inline-edit-app?file=src%2Fapp%2Fapp.component.html*/
import { Component, OnInit, Input, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-data-cell-vw',
  templateUrl: './data-cell-vw.component.html',
  styleUrls: ['./data-cell-vw.component.css']
})
export class DataCellVwComponent {
  static prevRow = 0;
  @Input() data: any;
  @Input() dataValue: any;
  @Input() left: any;
  @ViewChild('sn-cell-edit-input', null) searchElement: ElementRef;
  @Output() eSaveRow: EventEmitter<any> = new EventEmitter();
  @Output() eAfterCellEdit: EventEmitter<any> = new EventEmitter();
  editModeOn = false;
  constructor() { }

  onCellDoubleClick(element: HTMLElement, editor) {
    this.editModeOn = true;
    this.beforeShowEditMode();
    setTimeout(() => {
      DataCellVwComponent.prevRow = this.data.rNo;
      const domElem: any = document.getElementsByClassName('sn-cell-edit-input')[0];
      domElem.focus();
    }, 0);
  }
  onFocusOutFromEditMode() {
    this.editModeOn = false;
    this.eAfterCellEdit.emit({ rowNo: this.data.rNo, field: this.data.field, oldVal: this.data.oldVal, newVal: this.dataValue });
  }
  onFocusNonEditableCell() {
    // this.editModeOn = true;
     this.beforeShowEditMode();
    // if (DataCellVwComponent.prevRow !== this.data.rNo) {
    //   this.eSaveRow.emit();
    // }
    // setTimeout(() => {
    //   DataCellVwComponent.prevRow = this.data.rNo;
    //   const domElem: any = document.getElementsByClassName('sn-cell-edit-input')[0];
    //   domElem.focus();
    // }, 0);
  }

  beforeShowEditMode() {
    this.data.oldVal = this.dataValue;
  }

}
