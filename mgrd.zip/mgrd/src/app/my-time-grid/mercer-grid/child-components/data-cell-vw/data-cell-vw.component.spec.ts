import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataCellVwComponent } from './data-cell-vw.component';

describe('DataCellVwComponent', () => {
  let component: DataCellVwComponent;
  let fixture: ComponentFixture<DataCellVwComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataCellVwComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataCellVwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
