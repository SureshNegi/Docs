import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataGridComponent } from './data-grid/data-grid.component';
import { AngularSlickgridModule } from 'angular-slickgrid';
// import {NgxMaskModule, IConfig} from 'ngx-mask';
// export let options: Partial<IConfig> | (() => Partial<IConfig>);
import { InputMaskModule } from 'ng2-inputmask';
import { InputCEPCodeMaskDirective } from 'src/app/my-time-grid/input-mask.directive';
import { FormsModule } from '@angular/forms';
import { MercerGridComponent } from './mercer-grid/mercer-grid.component';
import { GridRoutingModule } from 'src/app/my-time-grid/grid-routing.moule';

import { AgGridModule } from 'ag-grid-angular';
import { AgGridDemoComponent } from './ag-grid-demo/ag-grid-demo.component';
import { MyGridTestComponent } from './my-grid-test/my-grid-test.component';
import { GridHeaderVwComponent } from './mercer-grid/child-components/grid-header-vw/grid-header-vw.component';
import { GridBodyVwComponent } from './mercer-grid/child-components/grid-body-vw/grid-body-vw.component';
import { GridColumnMenuVwComponent } from './mercer-grid/child-components/grid-column-menu-vw/grid-column-menu-vw.component';
import { DataCellVwComponent } from './mercer-grid/child-components/data-cell-vw/data-cell-vw.component';
// export const options: Partial<IConfig> | (() => Partial<IConfig>) = {}
@NgModule({
  declarations: [DataGridComponent, InputCEPCodeMaskDirective, MercerGridComponent, AgGridDemoComponent, MyGridTestComponent, GridHeaderVwComponent, GridBodyVwComponent, GridColumnMenuVwComponent, DataCellVwComponent],
  imports: [
    CommonModule, AngularSlickgridModule.forRoot(), FormsModule, GridRoutingModule, AgGridModule.withComponents([])
    // NgxMaskModule.forRoot(options),
    // InputMaskModule
  ],
  exports: [DataGridComponent]
})
export class MyTimeGridModule { }
