import { Component, OnInit, ViewChild } from '@angular/core';
import { MercerGridComponent } from 'src/app/my-time-grid/mercer-grid/mercer-grid.component';
import { AgGridAngular } from 'ag-grid-angular';

@Component({
  selector: 'app-my-grid-test',
  templateUrl: './my-grid-test.component.html',
  styleUrls: ['./my-grid-test.component.css']
})
export class MyGridTestComponent {
  columnDefs = [
    { headerName: 'Make', field: 'make', left: 0, sortable: true, sortDir: 0, width: 200 },
    { headerName: 'Model', field: 'model', left: 200, width: 200 },
    { headerName: 'Hours', field: 'hrs', left: 400, width: 200 }
  ];
  rowData = [
    { rowId: 1, make: '1', model: 'Celica', hrs: 35000, transformY: 0 },
    { rowId: 2, make: '2', model: 'Mondeo', hrs: 32000 },
    { rowId: 3, make: '3', model: 'Boxter', hrs: 72000 },
    { rowId: 4, make: '4', model: 'Celica', hrs: 35000 },
    { rowId: 5, make: '5', model: 'Mondeo', hrs: 32000 },
    { rowId: 6, make: '6', model: 'Boxter', hrs: 72000 },
    { rowId: 7, make: '7', model: 'Celica', hrs: 35000 },
    { rowId: 8, make: '8', model: 'Mondeo', hrs: 32000 },
    { rowId: 9, make: '9', model: 'Boxter', hrs: 72000 },
    { rowId: 10, make: '10', model: 'Celica', hrs: 35000 },
    { rowId: 11, make: '11', model: 'Mondeo', hrs: 32000 },
    { rowId: 12, make: '12', model: 'Boxter', hrs: 72000 }
  ];
  fields = ['make', 'model', 'hrs'];
  afterCellEdit(e) {
    if (e.field === 'hrs') {
      const flag = this.valiDateHoursToRollBack(e);
      flag && this.setRowFieldValueTo(e.rowNo, 'hrs', e.oldVal);
    }
  }

  valiDateHoursToRollBack(e) {
    if (e.newVal > 200) {
      // alert('hours exceeding');
      return true;
    }
  }
  setRowFieldValueTo(rNo, field, value) {
    setTimeout(() => {
      this.rowData.forEach(r => {
        if (r.rowId === rNo) {
          console.log('value before rolle back ' + r[field]);
          r[field] = value;
          console.log('value after rolle back ' + r[field]);
        }
      });
    }, 0);

  }
}

