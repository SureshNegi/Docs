import { Column, ColumnEditor, Editor, EditorValidator, EditorValidatorOutput, KeyCode } from 'angular-slickgrid';
import Inputmask from 'inputmask';
import { DataGridComponent } from './data-grid/data-grid.component';
import * as AppConfig from '../../global/app-config';
import { CEPCodeService } from 'src/services/cepcode.service';
// https://www.npmjs.com/package/ng2-input-mask
// using external non-typed js libraries
declare var $: any;
const empId = 249503;
const cmpId = 96;
const sessionKey = '91C8EBE0EAD5861A4F6D0ED5EB3E17F56AB00784CE15FF334A8709D17050662A';
const cepCodeMask = AppConfig.CEPCodeMaskInfo.MaskType1;
/*
 * An example of a 'detached' editor.
 * KeyDown events are also handled to provide handling for Tab, Shift-Tab, Esc and Ctrl-Enter.
 */
export class CustomInputEditor implements Editor {
  private lastInputEvent: KeyboardEvent;
  $input: any;
  $inlineEditor: any;
  defaultValue: any;
  component: DataGridComponent;

  constructor(private args: any, private cepService: CEPCodeService) {
    this.init();
  }

  /** Get Column Definition object */
  get columnDef(): Column {
    return this.args && this.args.column || {};
  }

  /** Get Column Editor object */
  get columnEditor(): ColumnEditor {
    return this.columnDef && this.columnDef.internalColumnEditor || {};
  }

  get hasAutoCommitEdit() {
    return this.args.grid.getOptions().autoCommitEdit;
  }

  /** Get the Validator function, can be passed in Editor property or Column Definition */
  get validator(): EditorValidator {
    return this.columnEditor.validator || this.columnDef.validator;
  }

  init(): void {
    const placeholder = this.columnEditor && this.columnEditor.placeholder || '';
    const title = this.columnEditor && this.columnEditor.title || '';

    // placeholder="${placeholder}"
    // tslint:disable-next-line:max-line-length
    // this.$input = $(`<input type="text" (keyup)="onKey()"  class="editor-text"  title="${title}" /><i class=\'fa fa-star-o\'></i></button><ul><li><li>Serch result here</ul>`)
    this.$inlineEditor = $(`#cepCodeInlineEditor`).appendTo(this.args.container);
    this.$inlineEditor.show();
    this.$input = $(`input`, this.$inlineEditor)
      .on('keydown.nav', (event: KeyboardEvent) => {
        this.lastInputEvent = event;
        if (event.keyCode === KeyCode.LEFT || event.keyCode === KeyCode.RIGHT) {
          event.stopImmediatePropagation();
        }
      });


    // .on('keyup', (event: KeyboardEvent) => {
    //   this.component.onKey();
    //   // this.cepService.lookupCEPCode(empId, 'DEVSEL-100-009', cmpId, sessionKey).subscribe(() => {
    //   //   console.log('api called');
    //   // });
    // });

    // the lib does not get the focus out event for some reason
    // so register it here
    if (this.hasAutoCommitEdit) {
      this.$input.on('focusout', () => this.save());
    }

    setTimeout(() => {
      this.$input.focus().select();
      // this.$input.mask('AAAA-999');
      // Inputmask({ 'mask': 'AAAAAA-999-999' }).mask($('.editor-text'));
    }, 50);
    this.addMaskingForCEPCode();
  }

  addMaskingForCEPCode() {
    Inputmask({ 'mask': cepCodeMask }).mask($('.editor-text'));
  }
  destroy() {
    this.$input.off('keydown.nav');
    //this.$inlineEditor.remove();
    $('#cepCodeInlineEditor').appendTo('#editorsContainer');
  }

  focus() {
    this.$input.focus();
  }

  getValue() {
    return this.$input.val();
  }

  setValue(val: string) {
    this.$input.val(val);
  }

  loadValue(item: any) {
    this.defaultValue = item[this.args.column.field] || '';
    this.$input.val(this.defaultValue);
    this.$input[0].defaultValue = this.defaultValue;
    this.$input.select();
  }

  serializeValue() {
    return this.$input.val();
  }

  applyValue(item: any, state: any) {
    const validation = this.validate(state);
    item[this.args.column.field] = (validation && validation.valid) ? state : '';
  }

  isValueChanged() {
    const lastEvent = this.lastInputEvent && this.lastInputEvent.keyCode;
    if (this.columnEditor && this.columnEditor.alwaysSaveOnEnterKey && lastEvent === KeyCode.ENTER) {
      return true;
    }
    return (!(this.$input.val() === '' && this.defaultValue === null)) && (this.$input.val() !== this.defaultValue);
  }

  save() {
    const validation = this.validate();
    if (validation && validation.valid) {
      if (this.hasAutoCommitEdit) {
        this.args.grid.getEditorLock().commitCurrentEdit();
      } else {
        this.args.commitChanges();
      }
    }
  }

  validate(inputValue?: any): EditorValidatorOutput {
    if (this.validator) {
      const value = (inputValue !== undefined) ? inputValue : this.$input && this.$input.val && this.$input.val();
      return this.validator(value, this.args);
    }

    return {
      valid: true,
      msg: null
    };
  }
}
