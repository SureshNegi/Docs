import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ag-grid-demo',
  templateUrl: './ag-grid-demo.component.html',
  styleUrls: ['./ag-grid-demo.component.css']
})
export class AgGridDemoComponent {

  title = 'app';

  columnDefs = [
    { headerName: 'Make', field: 'make', sortable: true },
    { headerName: 'Model', field: 'model', filter: true },
    { headerName: 'Price', field: 'price' }
  ];

  rowData = [
    { make: 'Toyota', model: 'Celica', price: 35000, sortable: true, filter: true },
    { make: 'Ford', model: 'Mondeo', price: 32000 },
    { make: 'Porsche', model: 'Boxter', price: 72000 },
    { make: 'Toyota', model: 'Celica', price: 35000 },
    { make: 'Ford', model: 'Mondeo', price: 32000 },
    { make: 'Porsche', model: 'Boxter', price: 72000 },
    { make: 'Toyota', model: 'Celica', price: 35000 },
    { make: 'Ford', model: 'Mondeo', price: 32000 },
    { make: 'Porsche', model: 'Boxter', price: 72000 }
  ];

  gridOptions = {
    defaultColDef: {
      filter: true
    },
    columnDefs: this.columnDefs,
    getMainMenuItems: this.getMainMenuItems,
    //     postProcessPopup: function(params) {
    //         // check callback is for menu
    //         if (params.type !== 'columnMenu') {
    //             return;
    //         }
    //         var columnId = params.column.getId();
    //         if (columnId === 'gold') {
    //             var ePopup = params.ePopup;

    //             var oldTopStr = ePopup.style.top;
    //             // remove 'px' from the string (ag-Grid uses px positioning)
    //             oldTopStr = oldTopStr.substring(0,oldTopStr.indexOf('px'));
    //             var oldTop = parseInt(oldTopStr);
    //             var newTop = oldTop + 25;

    //             ePopup.style.top = newTop + 'px';
    //         }
    //     }
    // }
  };
  getMainMenuItems(params) {
    switch (params.column.getId()) {
      case 'Model':
        var athleteMenuItems = params.defaultItems.slice(0);
        athleteMenuItems.push({
          name: "ag-Grid Is Great",
          action: function() {
            console.log("ag-Grid is great was selected");
          }
        });
        athleteMenuItems.push({
          name: "Casio Watch",
          action: function() {
            console.log("People who wear casio watches are cool");
          }
        });
        athleteMenuItems.push({
          name: "Custom Sub Menu",
          subMenu: [
            {
              name: "Black",
              action: function() {
                console.log("Black was pressed");
              }
            },
            {
              name: "White",
              action: function() {
                console.log("White was pressed");
              }
            },
            {
              name: "Grey",
              action: function() {
                console.log("Grey was pressed");
              }
            }
          ]
        });
        return athleteMenuItems;
      case "age":
        return [
          {
            name: "Joe Abercrombie",
            action: function() {
              console.log("He wrote a book");
            },
            icon: '<img src="../images/lab.png" style="width: 14px;"/>'
          },
          {
            name: "Larsson",
            action: function() {
              console.log("He also wrote a book");
            },
            checked: true
          },
          "resetColumns"
        ];
      case "country":
        var countryMenuItems = [];
        var itemsToExclude = ["separator", "pinSubMenu", "valueAggSubMenu"];
        params.defaultItems.forEach(function(item) {
          if (itemsToExclude.indexOf(item) < 0) {
            countryMenuItems.push(item);
          }
        });
        return countryMenuItems;
      default:
        return params.defaultItems;
    }
  }
}
