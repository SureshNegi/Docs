export const CEPCodeMaskInfo = { MaskType1: 'AAAAAA-999-999' };
export const APIBaseAddress = 'http://dev.api.mytime.mercer.com:8000/';

