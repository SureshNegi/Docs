import { IAPIOutObj, IAPIResponse } from 'src/models/api-response';


interface ILoginAPIOutObj extends IAPIOutObj {
    SESKEY: string;
    ENCKEY: string;
    EMPLID: number;
    ISNONAD: string;
    NONADUSERNAME: string;
    NONADPASSSTATUS: string;
    NONADDAYSTOEXPIRE: string;
    NONADLANG: string;
}

interface ILoginAPIResponse extends IAPIResponse {
    Data: ILoginAPIOutObj;
}
