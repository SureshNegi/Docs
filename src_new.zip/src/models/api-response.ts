export interface IAPIResponse {
    ResponseStatus: EnumAPIResponseStatus;
    AckMessage: string;
    Data: any;
}
export interface IAPIOutObj {
    RETCD: number;
    ERRMSG: string;
}
export enum EnumAPIResponseStatus {
    OK = 0,
    Error = 1,
    InvalidSession = 2,
    LogginFail = 3,
}
