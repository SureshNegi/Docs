import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, } from 'rxjs/operators';
import { APIBaseAddress } from '../global/app-config';
import { APINames } from '../global/api-url.config';

const apiParamPrefix = 'I_JSON';
export class CalandarService {
    constructor(private httpClient: HttpClient) { }
    static getRevenueMonthInfo(m, year) {
        const revenueMonthObj = { y: 0, m: 0, revStart: null, revEnd: {} };
        if (m === MonthNoEnum.APR) {
            revenueMonthObj.y = year;
            revenueMonthObj.m = m;
            revenueMonthObj.revStart = { m: MonthNoEnum.MAR, y: year, d: 30 };
            revenueMonthObj.revEnd = { m: MonthNoEnum.APR, y: year, d: 30 };
        } else if (m === MonthNoEnum.OCT) {
            revenueMonthObj.y = year;
            revenueMonthObj.m = m;
            revenueMonthObj.revStart = { m: MonthNoEnum.OCT, y: year, d: 1 };
            revenueMonthObj.revEnd = { m: MonthNoEnum.OCT, y: year, d: 31 };
        } else if (m === MonthNoEnum.NOV) {
            revenueMonthObj.y = year;
            revenueMonthObj.m = m;
            revenueMonthObj.revStart = { m: MonthNoEnum.NOV, y: year, d: 1 };
            revenueMonthObj.revEnd = { m: MonthNoEnum.NOV, y: year, d: 29 };
        } else if (m === MonthNoEnum.DEC) {
            revenueMonthObj.y = year;
            revenueMonthObj.m = m;
            revenueMonthObj.revStart = { m: MonthNoEnum.NOV, y: year, d: 30 };
            revenueMonthObj.revEnd = { m: MonthNoEnum.DEC, y: year, d: 31 };
        }
        return revenueMonthObj;
    }
    loadRevenueMonths(empId, revDate, sessKey) {
        const apiURL = `${APIBaseAddress}${APINames.loadRevenueMonths}`;
        const paramObj = { LOADREVM_IN_OBJ: { REVMDTE: revDate, EMPLID: empId } };
        const httpHeaders: HttpHeaders = new HttpHeaders().set('content-type', 'text/plain').set('authorization', sessKey);
        const paramString = `${apiParamPrefix}=${JSON.stringify(paramObj)}`;
        return this.httpClient.post<any>(apiURL, paramString, { headers: httpHeaders }).pipe(
            map(resp => {
                console.log();
                return resp;
            }),
            catchError(error => {
                return null;
                // throwError(error); // From 'rxjs'
            })
        );
    }
}

enum MonthNoEnum {
    JAN = 0,
    FEB = 1,
    MAR = 2,
    APR = 3,
    MAY = 4,
    JUNE = 5,
    JULY = 5,
    AUG = 7,
    SEP = 8,
    OCT = 9,
    NOV = 10,
    DEC = 11
}



