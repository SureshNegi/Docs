import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, } from 'rxjs/operators';
import { APIBaseAddress } from '../global/app-config';
import { APINames } from '../global/api-url.config';
const apiParamPrefix = 'I_JSON';

@Injectable()
export class CEPCodeService {
    constructor(private httpClient: HttpClient) { }
    lookupCEPCode(empId, cepSearch, cmpId, sessKey) {
        const apiURL = `${APIBaseAddress}${APINames.lookupCEPCode}`;
        const paramObj = {
            LOOKCEP_IN_OBJ: { EMPLID: 0, CEPFIND: '', PGNUM: 1, ROWSPP: 10, SRTCOL: '2,5,8', COMPID: 1 }
        };
        paramObj.LOOKCEP_IN_OBJ.EMPLID = empId;
        paramObj.LOOKCEP_IN_OBJ.CEPFIND = cepSearch;
        paramObj.LOOKCEP_IN_OBJ.COMPID = cmpId;
        const httpHeaders: HttpHeaders = new HttpHeaders().set('content-type', 'text/plain').set('authorization', sessKey);
        const paramString = `${apiParamPrefix}=${JSON.stringify(paramObj)}`;
        return this.httpClient.post<any>(apiURL, paramString, { headers: httpHeaders }).pipe(
            map(resp => {
                console.log();
                return resp;
            }),
            catchError(error => {
                return null;
                // throwError(error); // From 'rxjs'
            })
        );
    }
    loadCEPDetail(clientId, engId, prjId, sessKey) {
        const apiURL = `${APIBaseAddress}${APINames.loadCEPCodeDetails}`;
        const paramObj = {
            LOOKCEP_IN_OBJ: { CLIEID: clientId, ENGID: engId, PRJID: prjId }
        };
        const httpHeaders: HttpHeaders = new HttpHeaders().set('content-type', 'text/plain').set('authorization', sessKey);
        const paramString = `${apiParamPrefix}=${JSON.stringify(paramObj)}`;
        return this.httpClient.post<any>(apiURL, paramString, { headers: httpHeaders }).pipe(
            map(resp => {
                console.log();
                return resp;
            }),
            catchError(error => {
                return null;
                // throwError(error); // From 'rxjs'
            })
        );
    }
}



