export const APINames = {
    lookupCEPCode: 'te_html5_htp_pkg.lookupCEPCode',
    loadCEPCodeDetails: 'te_html5_htp_pkg.loadCEPCodeDetails',
    empLogin: 'te_html5_htp_pkg.Login',
    retrieveInitialData: 'te_html5_htp_pkg.retrieveInitialData',
    loadRevenueMonths: 'te_html5_htp_pkg.loadRevenueMonths'
};




