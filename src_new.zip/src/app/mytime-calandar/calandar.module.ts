import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MytimeCalandarComponent } from 'src/app/mytime-calandar/mytime-calandar.component';
import { CalandarRoutingModule } from 'src/app/mytime-calandar/calandar-routing.module.';

@NgModule({
  declarations: [MytimeCalandarComponent],
  imports: [
    CommonModule, CalandarRoutingModule
  ],
  exports: [MytimeCalandarComponent]
})
export class CalandarModule { }
