import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MytimeCalandarComponent } from './mytime-calandar.component';

describe('MytimeCalandarComponent', () => {
  let component: MytimeCalandarComponent;
  let fixture: ComponentFixture<MytimeCalandarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MytimeCalandarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MytimeCalandarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
