import { Component, OnInit } from '@angular/core';
import { CalandarService } from 'src/services/calandar.service';

@Component({
  selector: 'app-mytime-calandar',
  templateUrl: './mytime-calandar.component.html',
  styleUrls: ['./mytime-calandar.component.css']
})
export class MytimeCalandarComponent implements OnInit {
  constructor() { }
  calObj: ICalandar = new MyTimeCalandar();
  ngOnInit() {
    this.calObj.WeekStartFrom = WeekStartFromEnum.SUN;
    const revenueMonthObj = { y: 0, m: 0, revStart: null, revEnd: null };
    revenueMonthObj.y = 2019;
    revenueMonthObj.m = MonthNoEnum.SEP;
    revenueMonthObj.revStart = { m: MonthNoEnum.AUG, y: 2019, d: 31 };
    revenueMonthObj.revEnd = { m: MonthNoEnum.SEP, y: 2019, d: 30 };
    this.loadCalandar(revenueMonthObj);
  }
  public reRenderCalandarForRevenueMonth(revenuemonthObj: RevenueMonthInfo) {
    const obj = CalandarService.getRevenueMonthInfo(revenuemonthObj.Month, revenuemonthObj.Year);
    this.loadCalandar(obj);
  }

  loadNextMonth() {
    const obj = CalandarService.getRevenueMonthInfo(this.calObj.SelectedMonth + 1, 2019);
    this.calObj.SelectedMonth = this.calObj.SelectedMonth + 1;
    this.loadCalandar(obj);
  }
  loadPrevMonth() {
    const obj = CalandarService.getRevenueMonthInfo(this.calObj.SelectedMonth - 1, 2019);
    this.calObj.SelectedMonth = this.calObj.SelectedMonth - 1;
    this.loadCalandar(obj);
  }
  loadCalandar(revenueMonthObj) {
    this.calObj.SelectedMonth = revenueMonthObj.m;
    this.calObj.SelectedYear = revenueMonthObj.y;
    // tslint:disable-next-line:max-line-length
    this.calObj.MonthRevenueStartDateInfo = { Year: revenueMonthObj.revStart.y, Month: revenueMonthObj.revStart.m, Date: revenueMonthObj.revStart.d };
    // tslint:disable-next-line:max-line-length
    this.calObj.MonthRevenueEndDateInfo = { Year: revenueMonthObj.revEnd.y, Month: revenueMonthObj.revEnd.m, Date: revenueMonthObj.revEnd.d };
    this.calObj.WeekDaysDisPlayName = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    this.calObj.MonthHeader = this.prepareCalMonthHeader();
    this.prepareCalaData();
  }
  prepareCalaData() {
    let datesRow: DateInfo[] = [];
    const renderFromDate: DateInfo = this.getCalRenderFromDate();
    const sDate = renderFromDate.Date;
    this.calObj.RowsToRender = [];
    const calStartDate = this.createDate(renderFromDate.Year, renderFromDate.Month, renderFromDate.Date);
    for (let j = 0; j < 6; j++) {
      // const rowStartDate = { ...calStartDate };
      const rowStartDate = this.createDate(calStartDate.getFullYear(), calStartDate.getMonth(), calStartDate.getDate());
      datesRow = [];
      if (j) {
        rowStartDate.setDate(sDate + j * 7);
      }
      for (let i = 0; i < 7; i++) {

        const calDate = this.createDate(rowStartDate.getFullYear(), rowStartDate.getMonth(), rowStartDate.getDate());
        if (i) {
          calDate.setDate(rowStartDate.getDate() + i);
        }
        const dateObj: DateInfo = new DateInfo();
        dateObj.Date = calDate.getDate();
        dateObj.Month = calDate.getMonth();
        dateObj.Year = calDate.getFullYear();
        dateObj.Title = `${dateObj.Date}-${dateObj.Month}-${dateObj.Year}`;
        dateObj.IsIcEntryExist = (i % 2 === 0) ? true : false;
        if (this.isDateInSelectedRevenueMonth(dateObj)) {
          dateObj.FallIn = DateFallInEnum.CurrentRevMonth;
          dateObj.CSSClass = DateCSSClassEnum.OpenRevMonth;
        }
        datesRow.push(dateObj);
      }
      const row: RowToRender = new RowToRender();
      row.Dates = datesRow;
      this.calObj.RowsToRender.push(row);
    }
  }
  isDateInSelectedRevenueMonth(dateObj: DateInfo) {
    const revSDteInfo = this.calObj.MonthRevenueStartDateInfo;
    const revEDteInfo = this.calObj.MonthRevenueEndDateInfo;
    const revSdte = this.createDate(revSDteInfo.Year, revSDteInfo.Month, revSDteInfo.Date);
    const revEdte = this.createDate(revEDteInfo.Year, revEDteInfo.Month, revEDteInfo.Date);
    const dateToCheck = this.createDate(dateObj.Year, dateObj.Month, dateObj.Date);
    if (dateToCheck >= revSdte && dateToCheck <= revEdte) {
      return true;
    }
    return false;
  }
  getCalRenderFromDate() {
    const selectedMonth = this.calObj.SelectedMonth;
    const selectedYear = this.calObj.SelectedYear;
    const revStartDate = this.calObj.MonthRevenueStartDateInfo.Date;
    const revStartMonth = this.calObj.MonthRevenueStartDateInfo.Month;
    const startCalRenderDateFrom: DateInfo = new DateInfo();
    startCalRenderDateFrom.Date = revStartDate;
    startCalRenderDateFrom.Month = revStartMonth;
    startCalRenderDateFrom.Year = selectedYear;
    // tslint:disable-next-line:max-line-length
    const date = new Date(this.calObj.MonthRevenueStartDateInfo.Year, revStartMonth, revStartDate);
    const weekDayNo = date.getDay();
    let dayOffsetToSubtract = 0;
    if (weekDayNo !== this.calObj.WeekStartFrom) {
      dayOffsetToSubtract = weekDayNo - this.calObj.WeekStartFrom;
    }

    for (let i = 0; i < dayOffsetToSubtract; i++) {
      if (startCalRenderDateFrom.Date === 1) {
        startCalRenderDateFrom.Date = this.getMonthLastDate(selectedYear, selectedMonth);
        startCalRenderDateFrom.Month = revStartMonth - 1;
      } else {
        startCalRenderDateFrom.Date = startCalRenderDateFrom.Date - 1;
      }
    }
    return startCalRenderDateFrom;
    // alert(JSON.stringify(startCalRenderDateFrom));
  }
  createDate(y, m, d) {
    return new Date(y, m, d);
  }
  prepareCalMonthHeader() {
    const monthNames = ['Jan', 'FEB', 'MAR', 'APR', 'MAY', 'JUNE', 'JULY', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    const revMonth = this.calObj.SelectedMonth;
    const revYr = this.calObj.SelectedYear;
    return `${monthNames[revMonth]} ${revYr}`;
  }
  getCalRenderToDate() {
    const selectedMonth = this.calObj.SelectedMonth;
    const selectedYear = this.calObj.SelectedYear;
    const revStartDate = this.calObj.MonthRevenueStartDateInfo.Date;
    const revStartMonth = this.calObj.MonthRevenueStartDateInfo.Month;
    const startCalRenderDateFrom: DateInfo = new DateInfo();
    startCalRenderDateFrom.Date = revStartDate;
    startCalRenderDateFrom.Month = revStartMonth;
    startCalRenderDateFrom.Year = selectedYear;
    // tslint:disable-next-line:max-line-length
    const date = new Date(this.calObj.MonthRevenueStartDateInfo.Year, revStartMonth, revStartDate);
    const weekDayNo = date.getDay();
    let dayOffsetToSubtract = 0;
    if (weekDayNo !== this.calObj.WeekStartFrom) {
      dayOffsetToSubtract = weekDayNo - this.calObj.WeekStartFrom;
    }
    for (let i = 0; i < dayOffsetToSubtract; i++) {
      if (revStartDate === 1) {
        startCalRenderDateFrom.Date = this.getMonthLastDate(selectedYear, selectedMonth);
        startCalRenderDateFrom.Month = revStartMonth - 1;
      } else {
        startCalRenderDateFrom.Date = startCalRenderDateFrom.Date - 1;
      }
    }
    return startCalRenderDateFrom;
    // alert(JSON.stringify(startCalRenderDateFrom));
  }
  getMonthLastDate(year, month) {
    const date = new Date(year, month, 0);
    return date.getDate();
  }
}

interface ICalNavigation {
  IsNavigationEnable: boolean;
  LoadPreviousMonthTitle: string;
  LoadNextMonthTitle: string;
}
class DateInfo {
  CSSClass: string;
  Title: string;
  Date: number;
  Year: number;
  Month: number;
  FallIn: DateFallInEnum;
  IsIcEntryExist: boolean;
  constructor() {
    this.CSSClass = DateCSSClassEnum.Default;
  }
}
class RowToRender {
  Dates: DateInfo[];
}
class RevenueMonthInfo {
  Year: number;
  Month: number;
  Date: number;
}
interface ICalandar {
  WeekDaysDisPlayName: string[];
  SelectedMonth: MonthNoEnum;
  SelectedYear: number;
  DateObj: DateInfo;
  NavigationConfig: ICalNavigation;
  RowsToRender: RowToRender[];
  MonthRevenueStartDateInfo: RevenueMonthInfo;
  MonthRevenueEndDateInfo: RevenueMonthInfo;
  WeekStartFrom: WeekStartFromEnum;
  MonthHeader: string;
}

class MyTimeCalandar implements ICalandar {
  WeekDaysDisPlayName: string[];
  SelectedMonth: number;
  SelectedYear: number;
  NavigationConfig: ICalNavigation;
  DateObj: DateInfo;
  RowsToRender: RowToRender[];
  MonthRevenueStartDateInfo: RevenueMonthInfo;
  MonthRevenueEndDateInfo: RevenueMonthInfo;
  WeekStartFrom: WeekStartFromEnum;
  MonthHeader: string;
  constructor() {
    this.RowsToRender = [];
  }
}

enum MonthNoEnum {
  JAN = 0,
  FEB = 1,
  MAR = 2,
  APR = 3,
  MAY = 4,
  JUNE = 5,
  JULY = 5,
  AUG = 7,
  SEP = 8,
  OCT = 9,
  NOV = 10,
  DEC = 11
}
enum WeekStartFromEnum {
  SUN = 0,
  MON = 1,
  TUE = 2,
  WED = 3,
  THUR = 4,
  FRI = 5,
  SAT = 6
}
enum DateFallInEnum {
  PrevRevMonth,
  CurrentRevMonth,
  NextRevMonth
}
enum DateCSSClassEnum {
  Default = 'default',
  OpenRevMonth = 'dt-available',
  ClosedRevMonth = 'disable-ctrl'
}

