import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MytimeCalandarComponent } from 'src/app/mytime-calandar/mytime-calandar.component';
const loginRoutes: Routes = [
    {
        path: '',
        component: MytimeCalandarComponent
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(loginRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class CalandarRoutingModule { }
