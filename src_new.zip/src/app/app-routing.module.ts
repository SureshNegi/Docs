import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  // { path: 'dashboard', component: DashboardComponent },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then(mod => mod.LoginModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard-module/dashboard.module').then(mod => mod.DashboardModule)
  },
  {
    path: 'grid',
    loadChildren: () => import('./my-time-grid/my-time-grid.module').then(mod => mod.MyTimeGridModule)
  },
  {
    path: 'calandar',
    loadChildren: () => import('./mytime-calandar/calandar.module').then(mod => mod.CalandarModule)
  },
  /*if invalid route then navigate to dashboard */
  { path: '**', redirectTo: '/dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
