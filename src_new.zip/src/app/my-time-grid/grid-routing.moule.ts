import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MercerGridComponent } from './mercer-grid/mercer-grid.component';
import { AgGridDemoComponent } from './ag-grid-demo/ag-grid-demo.component';
import { MyGridTestComponent } from './my-grid-test/my-grid-test.component';

const gridRoutes: Routes = [
    { path: '', redirectTo: 'demo', pathMatch: 'full' },
    {
        path: 'demo',
        component: MyGridTestComponent
    },
    {
        path: 'ag-grid',
        component: AgGridDemoComponent
    },
    {
        path: 'mygrid-test',
        component: MyGridTestComponent
    }
];

@NgModule({
    imports: [
        RouterModule.forChild(gridRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class GridRoutingModule { }
