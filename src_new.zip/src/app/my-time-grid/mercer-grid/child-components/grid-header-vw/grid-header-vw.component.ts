import { Component, OnChanges, OnInit, Output, Input, EventEmitter, DoCheck, IterableDiffers } from '@angular/core';

// tslint:disable-next-line:no-conflicting-lifecycle
@Component({
  selector: 'app-sn-grid-header-vw',
  templateUrl: './grid-header-vw.component.html',
  styleUrls: ['./grid-header-vw.component.css']
})
export class GridHeaderVwComponent implements OnInit, OnChanges {

  @Input() columnDefs: any;
  @Input() headerHeight = 32;
  @Output() eTriggerSort: EventEmitter<any> = new EventEmitter();
  @Output() eTriggerSearch: EventEmitter<any> = new EventEmitter();
  @Output() eTriggerColMenu: EventEmitter<any> = new EventEmitter();
  @Output() eTriggerColPosChange: EventEmitter<any> = new EventEmitter();
  iterableDiffers2: any;
  filterObj: any = {};
  menuObj: any = {};
  cellWidth = 200;
  gridColDragDropObj = { dragIndex: 0, dropToIndes: 0 };
  constructor(private iterableDiffers: IterableDiffers) {
    this.iterableDiffers2 = this.iterableDiffers.find([]).create(null);
  }
  // tslint:disable-next-line:use-lifecycle-interface
  // ngDoCheck() {
  //   const changes = this.iterableDiffers2.diff(this.columnDefs);
  //   if (changes) {
  //     console.log('Changes detected!');
  //   }
  // }
  ngOnChanges(data): void {
    this.columnDefs = data.columnDefs.currentValue;
    console.log('ngOnChanges detected!');
  }
  ngOnInit() {
    // this.columnDefs.forEach((c) => {
    //   this.filterObj[c.field] = '';
    // });
  }

  /*
    https://stackoverflow.com/questions/49986104/drag-event-not-firing-with-angular-2?noredirect=1&lq=1
  */
  onDragStart(event, index) {
    // event.preventDefault();
    console.log('drag==' + index);
    this.gridColDragDropObj.dragIndex = index;
    event.target.style.opacity = 1;
    // event.stopPropagation();
  }
  onDragOver(event) {
    event.preventDefault();
  }
  onDragEnd(event, index) {
    console.log('drop to==' + index);
  }
  onDrop(event, index) {
    const temp = JSON.parse(JSON.stringify(this.columnDefs[index]));
    this.updateObj(this.columnDefs[index], this.columnDefs[this.gridColDragDropObj.dragIndex]);
    this.updateObj(this.columnDefs[this.gridColDragDropObj.dragIndex], temp);
    this.eTriggerColPosChange.emit(this.columnDefs);
    // this.columnDefs = [].concat(this.columnDefs);
    // event.preventDefault();
  }
  updateObj(source, target) {
    source.field = target.field;
    source.headerName = target.headerName;
    // source.left = target.left;
    source.trackIndex = target.trackIndex;
    source.width = target.width;
  }

  onSort(c) {
    this.columnDefs.forEach(r => {
      if (r.field !== c.field) { (r.sortDir = 0); }
    });
    c.sortDir = (c.sortDir === 0) ? 1 : (c.sortDir === 1 ? 2 : 1);
    this.eTriggerSort.emit(c);
  }
  onSearchChange(searchString, searchedCol) {
    this.filterObj[searchedCol.field] = searchString;
    this.eTriggerSearch.emit(this.filterObj);
  }
  showFilterMenu(column) {
    this.eTriggerColMenu.emit(this.filterObj);
    // this.menuObj.showFilterMenu = true;
  }

}
