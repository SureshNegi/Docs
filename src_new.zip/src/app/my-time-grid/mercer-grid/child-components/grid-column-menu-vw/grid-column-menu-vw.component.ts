import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-grid-column-menu-vw',
  templateUrl: './grid-column-menu-vw.component.html',
  styleUrls: ['./grid-column-menu-vw.component.css']
})
export class GridColumnMenuVwComponent implements OnInit {
  menuObj = { show: false };
  constructor() { }

  ngOnInit() {
  }
  loadColMenu(args) {
    this.menuObj.show = true;
  }
  applyFilter() {
    alert('hi');
  }
}
