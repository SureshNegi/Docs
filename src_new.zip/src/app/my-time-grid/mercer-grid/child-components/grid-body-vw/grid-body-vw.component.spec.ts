import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GridBodyVwComponent } from './grid-body-vw.component';

describe('GridBodyVwComponent', () => {
  let component: GridBodyVwComponent;
  let fixture: ComponentFixture<GridBodyVwComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GridBodyVwComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridBodyVwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
