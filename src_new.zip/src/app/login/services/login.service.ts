import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, mergeMap } from 'rxjs/operators';
import { APIBaseAddress } from '../../../global/app-config';
import { APINames } from '../../../global/api-url.config';
import { EmpService } from 'src/services/emp.service';
import { Observable } from 'rxjs';
import { IAPIResponse } from 'src/models/api-response';
import { EnumAPIResponseStatus } from 'src/models/api-response';
const apiParamPrefix = 'I_JSON';

@Injectable()
export class LoginService {
    constructor(private httpClient: HttpClient, private empService: EmpService) { }
    employeeLogin(uName, pass, clType, apVer, uAgent) {
        const apiURL = `${APIBaseAddress}${APINames.empLogin}`;
        const paramObj = {
            LOGIN_IN_OBJ: { USRNAME: uName, PW: pass, CLITYP: clType, APPVER: apVer, UAGENT: uAgent }
        };
        const paramString = `${apiParamPrefix}=${JSON.stringify(paramObj)}`;
        return this.httpClient.post<IAPIResponse>(apiURL, paramString).pipe(map(dd => {
            // // tslint:disable-next-line:max-line-length
            // if (+(dd['LOGIN_OUT_OBJ']['RETCD']) === 0) {
            //     mergeMap((param) => {
            //         return this.empService.retrieveInitialData(param['LOGIN_OUT_OBJ.EMPLID'], param['LOGIN_OUT_OBJ.SESKEY'])
            //         .pipe(map(fff => {
            //             return this.parseInitialDataAPIResponse(dd);
            //         }));
            //     });
            // } else {
            //     return this.parseLoginAPIResponse(dd);
            // }
            return this.parseLoginAPIResponse(dd);
        })
        );
    }
    parseLoginAPIResponse(apiObj) {
        const repObj: IAPIResponse = {} as IAPIResponse;
        if (+apiObj.LOGIN_OUT_OBJ.RETCD === 0) {
            repObj.ResponseStatus = EnumAPIResponseStatus.OK;
            // repObj.Data=apiObj.LOGIN_OUT_OBJ
        } else {
            repObj.ResponseStatus = EnumAPIResponseStatus.LogginFail;
            repObj.AckMessage = apiObj.LOGIN_OUT_OBJ.ERRMSG;
        }
        return repObj;
    }
    parseInitialDataAPIResponse(apiObj) {
        const repObj: IAPIResponse = {} as IAPIResponse;
        if (+apiObj.LOGIN_OUT_OBJ.RETCD === 0) {
            repObj.ResponseStatus = EnumAPIResponseStatus.OK;
            // repObj.Data=apiObj.LOGIN_OUT_OBJ
        } else {
            repObj.ResponseStatus = EnumAPIResponseStatus.LogginFail;
            repObj.AckMessage = apiObj.LOGIN_OUT_OBJ.ERRMSG;
        }
        return repObj;
    }
    getInitialData(empId, sessionKey) {
        return this.empService.retrieveInitialData(empId, sessionKey)
            .pipe(map(fff => {
                return this.parseInitialDataAPIResponse(dd);
            }));

    }
}



