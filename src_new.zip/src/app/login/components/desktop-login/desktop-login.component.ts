import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/login/services/login.service';
import { Router } from '@angular/router';
import { IAPIResponse, EnumAPIResponseStatus } from 'src/models/api-response';
import { EmpService } from 'src/services/emp.service';

@Component({
  selector: 'app-desktop-login',
  templateUrl: './desktop-login.component.html',
  styleUrls: ['./desktop-login.component.css'],
  providers: [LoginService]
})
export class DesktopLoginComponent implements OnInit {

  constructor(private loginService: LoginService, private router: Router, private empService: EmpService) { }

  ngOnInit() {
  }

  getClienttype(): EnumClientType {
    let obj: EnumClientType = EnumClientType.Other;
    if (/BlackBerry/i.test(window.navigator.userAgent)) {
      obj = EnumClientType.BlackBerry;
    } else if (/iPhone/i.test(window.navigator.userAgent)) {
      obj = EnumClientType.IPhone;
    } else if (/iPad/i.test(window.navigator.userAgent)) {
      obj = EnumClientType.IPad;
    }
    return obj;
  }
  login() {
    let uAgent = window.navigator.userAgent;
    uAgent = uAgent.substring(0, 100);
    const cType = this.getClienttype();
    this.loginService.employeeLogin('suresh-negi s', 'mercer@2019', cType, 1.8, uAgent).subscribe((resp: IAPIResponse) => {
      if (resp.ResponseStatus === EnumAPIResponseStatus.OK) {
        this.empService.retrieveInitialData(resp.Data.)
      } else {

      }
      // this.router.navigate(['/dashboard']);
    });
  }
}

enum EnumClientType {
  IPhone = 'iPhone',
  IPad = 'iPad',
  BlackBerry = 'BlackBerry',
  Other = 'Other'
}


