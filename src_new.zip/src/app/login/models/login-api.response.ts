export interface IUserSessionInfo {
    EmpId: number;
    EncKey: string;
    IsNonAd: boolean;
    AuthToken: string;
}
