import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { TranslateService } from 'src/app/translate.service';
import { CalandarService } from 'src/services/calandar.service';
import { MytimeCalandarComponent } from 'src/app/mytime-calandar/mytime-calandar.component';
const empId = 249503;
const cmpId = 96;
const sessionKey = '6D21ED011ACCF87C780431C2A8EB1CA162CFCA6578292D481A2A428C3C83BAA6';

@Component({
  selector: 'app-dashboard-view',
  templateUrl: './dashboard-view.component.html',
  styleUrls: ['./dashboard-view.component.css'],
  providers: [TranslateService, CalandarService]
})
export class DashboardViewComponent implements OnInit {
  @ViewChild('revCalandar', { read: false, static: true }) calObj: MytimeCalandarComponent;
  constructor(private translate: TranslateService, private calService: CalandarService) {
    translate.use('fr').then(() => {
      console.log(translate.data);
    });
  }

  ngOnInit() {
    const selectedDate = '2019-04-04';
    this.calService.loadRevenueMonths(empId, selectedDate, sessionKey).subscribe((resp) => {
      const revenueMonthsInfo: ICPNRevenueMonthInfo = {} as ICPNRevenueMonthInfo;
      const revAr = resp.LOADREVM_OUT_OBJ.REVM_ARR;
      revenueMonthsInfo.CurrentRevMonthInfo = revAr[0];
      revenueMonthsInfo.PrevRevMonthInfo = revAr[1];
      revenueMonthsInfo.NextRevMonthInfo = revAr[2];
      const calRevMonthObj: ICalRevenueMonthInfo = {} as ICalRevenueMonthInfo;
      calRevMonthObj.Year = +revenueMonthsInfo.CurrentRevMonthInfo.REVM.substring(0, 4);
      calRevMonthObj.Month = (+revenueMonthsInfo.CurrentRevMonthInfo.REVM.substring(4)) - 1;
      calRevMonthObj.Date = 5;
      this.calObj.reRenderCalandarForRevenueMonth(calRevMonthObj);
    });
  }

}
interface ICalRevenueMonthInfo {
  Year: number;
  Month: number;
  Date: number;
}
interface IRevenueMonthInfo {
  REVM: string;
  STRTDTE: string;
  ENDDTE: string;
  TECUTTOFF: string;
}
interface ICPNRevenueMonthInfo {
  CurrentRevMonthInfo: IRevenueMonthInfo;
  PrevRevMonthInfo: IRevenueMonthInfo;
  NextRevMonthInfo: IRevenueMonthInfo;
};