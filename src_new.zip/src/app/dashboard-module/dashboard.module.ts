import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainComponent } from './components/main-content-view/main.component';
import { DashboardViewComponent } from './components/dashboard-view/dashboard-view.component';
import { DashboardRoutingModule } from 'src/app/dashboard-module/dashboard-routing.module.';
import { HeaderComponent } from './components/header-view/header.component';
import { AppSharedModule } from 'src/app/shared.module';
import { TranslatePipe } from 'src/app/translate.pipe';
import { CalandarModule } from 'src/app/mytime-calandar/calandar.module';

@NgModule({
  declarations: [MainComponent, DashboardViewComponent, HeaderComponent],
  imports: [
    CommonModule, DashboardRoutingModule, AppSharedModule, CalandarModule
  ]
})
export class DashboardModule { }
