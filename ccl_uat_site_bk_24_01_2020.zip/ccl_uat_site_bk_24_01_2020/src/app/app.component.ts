import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { CoreMessageService } from './modules/core/core-message.service';
import { WebConfigObj } from './modules/core/api-response.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'CCL-UAT-SITE';
  constructor(private titleService: Title, private coreMessageService: CoreMessageService) {
    this.coreMessageService.getAppConfiguration().subscribe((data: WebConfigObj) => {
      this.titleService.setTitle(data.APP_TITLE);
    });
  }
}
