
export interface FeedbackItemPageParam {
    selectedRowId: number;
    appName: string;
    cclNo: number;
    cclDesc: string;
    empNo: number;
}
