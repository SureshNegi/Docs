import { Component, OnInit, EventEmitter, Output, Input, OnChanges } from '@angular/core';

import { AddFeedbackItemComponent } from '../add-feedback-item/add-feedback-item.component';
import { FeedbaackItemFullVwComponent } from '../feedbaack-item-full-vw/feedbaack-item-full-vw.component';
import * as GLOBAL_CONST from 'src/app/modules/models/global.const';
import { CCLStatusType, FilterType } from '../../../models/common.models';

@Component({
  selector: 'app-data-grid',
  templateUrl: './data-grid.component.html',
  // styleUrls: ['./data-grid.component.scss']
})
export class DataGridComponent implements OnInit, OnChanges {
  @Input() columnDefinitions: any[] = [];
  @Input() dataset: any[] = [];
  @Input() grdId = '';
  @Input() availableHeightForGrid = 100;
  statusEditOptions: typeof GLOBAL_CONST.STATUS_FILTER_OPTIONS;
  selectedStatusOptOnEditMode: FilterType;
  slickGrid: any;
  constructor() { }
  ngOnInit() {
    this.statusEditOptions = GLOBAL_CONST.STATUS_FILTER_OPTIONS.filter((item: FilterType) => {
      return item.id !== CCLStatusType.All;
    });
  }
  ngOnChanges() {
    console.log(this.columnDefinitions);
  }
}


