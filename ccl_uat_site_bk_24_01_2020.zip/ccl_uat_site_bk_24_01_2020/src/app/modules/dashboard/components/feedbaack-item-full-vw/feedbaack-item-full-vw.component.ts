import { Component, OnInit, ViewChild, ElementRef, Input, OnChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { BaseResponseType } from '../../../models/api.models';
import { FeedbackItem, FbItemFullVwInputParam, FeedbackSDRItem } from '../../../models/common.models';
import { FeedbackItemsService } from '../../services/feedback.items.service';
import { EnumAPIResponseStatus } from '../../../core/api-response.model';


@Component({
  selector: 'app-feedbaack-item-full-vw',
  templateUrl: './feedbaack-item-full-vw.component.html',
  // styleUrls: ['./feedbaack-item-full-vw.component.scss']
})
export class FeedbaackItemFullVwComponent implements OnInit, OnChanges {
  @ViewChild('outerMostDiv', null) parentElem: ElementRef;
  @Input() data: FbItemFullVwInputParam;
  historyViewO: any = { columns: [], dataset: [] };
  sdrViewO: any = { columns: [], dataset: [] };
  addFeedbackFrm: FormGroup;
  submitted = false;
  availableHeightForGrid = 0;
  formObj = {
    comment: ['', Validators.required],
    attachement: ['']
  };
  constructor(private fb: FormBuilder, private model: NgbActiveModal, private feedbackService: FeedbackItemsService) {
    this.createForm();
  }
  ngOnInit() {
    this.setGridCoumns();
    setTimeout(() => {
      this.availableHeightForGrid = (this.parentElem.nativeElement.offsetHeight - 50);
    }, 0);
    if (this.data) {
      this.callAPIToGetHistory();
    }

  }
  ngOnChanges() {
    if (this.data) {
      this.callAPIToGetHistory();
    }
  }
  get f() {
    return this.addFeedbackFrm.controls;
  }
  createForm() {
    this.addFeedbackFrm = this.fb.group(this.formObj);
  }
  callAPIToGetHistory() {
    // tslint:disable-next-line:max-line-length
    this.feedbackService.getFeedbackItemHistory({ cuauValue: this.data.cuauId, fbId: this.data.fbId }).subscribe((data: BaseResponseType) => {
      if (data.responseCode === EnumAPIResponseStatus.OK) {
        this.historyViewO.dataset = data.data as FeedbackItem[];
      }
    }, error => null);
  }
  callAPIToGetSDRData() {
    // tslint:disable-next-line:max-line-length
    this.feedbackService.getFeedbackItemSDRs({ cuauValue: this.data.cuauId, fbId: this.data.fbId }).subscribe((data: BaseResponseType) => {
      if (data.responseCode === EnumAPIResponseStatus.OK) {
        this.sdrViewO.dataset = data.data as FeedbackSDRItem[];
      }
    }, error => null);
  }
  showHistoryVw() {
    this.callAPIToGetHistory();
  }
  showSDRTabVw() {
    this.callAPIToGetSDRData();
  }
  submitFeedback() {
    this.submitted = true;
    if (this.addFeedbackFrm.valid) {
      const feedback: FeedbackItem = {} as FeedbackItem;
      feedback.fileName = '';
      feedback.comment = this.addFeedbackFrm.controls['comment'].value;
      feedback.stage = '1';
      feedback.status = '1';
      feedback.fbId = 12;
      this.model.close(feedback);
    }
    // this.apiErrorMessage = 'Error : Invalid Login, please try again.';
  }
  closeModel() {
    this.model.dismiss();
  }
  setGridCoumns() {
    this.historyViewO.columns = [
      {
        name: 'Comment', field: 'comment', sortable: true, minWidth: 500, width: 500
      },
      { name: 'File', field: 'fileName', sortable: true },
      {
        name: 'Status', field: 'status', sortable: true
      },
      { name: 'Last Updated', field: 'updatedOn', sortable: true }
    ];
    this.sdrViewO.columns = [
      {
        id: 'markAs', name: 'Mark as', field: 'markedAs', sortable: true, editable: true
      },
      { id: 'sdrNo', name: 'SDR #', field: 'sdrNo', sortable: true },
      {
        id: 'desc', name: 'Description', field: 'desc', sortable: true
      },
      { id: 'status', name: 'Status', field: 'status', sortable: true }
    ];
  }

}
