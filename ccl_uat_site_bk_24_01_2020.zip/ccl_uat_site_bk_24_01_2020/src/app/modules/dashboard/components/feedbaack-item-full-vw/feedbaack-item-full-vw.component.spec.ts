import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbaackItemFullVwComponent } from './feedbaack-item-full-vw.component';

describe('FeedbaackItemFullVwComponent', () => {
  let component: FeedbaackItemFullVwComponent;
  let fixture: ComponentFixture<FeedbaackItemFullVwComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbaackItemFullVwComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbaackItemFullVwComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
