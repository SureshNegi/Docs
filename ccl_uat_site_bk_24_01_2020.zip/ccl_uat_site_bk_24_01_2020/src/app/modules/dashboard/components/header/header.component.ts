import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  // styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() userName: string;
  // tslint:disable-next-line:no-output-on-prefix
  @Output() onLogout: EventEmitter<any> = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
  logOut(event) {
    event.stopPropagation();
    event.preventDefault();
    this.onLogout.emit();
  }

}
