import { Component, OnInit, EventEmitter, Output, Input, OnChanges, ViewChild } from '@angular/core';
import { formatNumber } from '@angular/common';
// import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { AddFeedbackItemComponent } from '../../components/add-feedback-item/add-feedback-item.component';
import { FeedbaackItemFullVwComponent } from '../feedbaack-item-full-vw/feedbaack-item-full-vw.component';
import { FeedbackItemsService } from '../../services/feedback.items.service';
import {
  BaseDataFilter, CCLStatusType, FeedbackItem, FilterType,
  FbItemFullVwInputParam, AddFbItemVwInputParam
} from '../../../models/common.models';
import { CoreService } from '../../../core/core.service';
import { BaseResponseType } from '../../../models/api.models';
import { EnumAPIResponseStatus } from '../../../core/api-response.model';
import { FeedbackItemPageParam } from '../../models/feedbackItem';
import * as GLOBAL_CONST from 'src/app/modules/models/global.const';
import { CommonUtilityService } from '../../services/common.utility.service';
import { CoreAlertService } from '../../../core/core.alert.service';
import { Table } from 'primeng/table';

@Component({
  selector: 'app-feedback-items-details',
  templateUrl: './feedback-items-details.component.html',
  // styleUrls: ['./feedback-items-details.component.scss']
})
export class FeedbackItemsComponent implements OnChanges, OnInit {
  @Output() loadMainView = new EventEmitter();
  @Input() selectedRowObj: FeedbackItemPageParam;
  @ViewChild('dt', null) dt: Table;
  filterObj: BaseDataFilter;
  selectedStatusOptOnEditMode: FilterType = {} as FilterType;
  statusOptions = GLOBAL_CONST.STATUS_FILTER_OPTIONS;
  stageOptions = GLOBAL_CONST.STAGE_FILTER_OPTIONS;
  statusEditOptions: typeof GLOBAL_CONST.STATUS_FILTER_OPTIONS;
  columnDefinitions: any[] = [];
  dataset: any[];
  defaultStatusFilter = { id: CCLStatusType.Unsucessfull, name: 'Unsucessfull' };
  constructor(private coreAlertService: CoreAlertService, private dataService: FeedbackItemsService) {
    this.filterObj = new BaseDataFilter(0, 'fbNo', { id: CCLStatusType.All, name: 'All' } as FilterType);
    this.setGridCoumns();
  }
  ngOnInit() {
    this.statusEditOptions = this.statusOptions.filter((item: FilterType) => {
      return item.id !== CCLStatusType.All;
    });
  }
  ngOnChanges() {
    if (this.selectedRowObj) {
      this.filterObj.EmplNo = this.selectedRowObj.empNo;
      this.getFeedbackItems();
    }
  }
  editInit(args) {
    // this.selectedStatusOptOnEditMode = { id: args.data.status } as FilterType;
    const editingRow: FeedbackItem = args.data;
    this.selectedStatusOptOnEditMode = {} as FilterType;
    this.selectedStatusOptOnEditMode.id = editingRow.status;
  }
  updateStatusFilter(value) {
    console.log(this.filterObj.Status);
    // this.filterObj.Status = value.id;
    this.getFeedbackItems();
  }

  updateFBStatus(value: FilterType, rowData: FeedbackItem) {
    this.filterObj.SelectetdRecord = { id: rowData.fbId, cclNo: 0, data: rowData };
    // this.filterObj.SelectetdRecord.data.status = CCLStatusType.Unsucessfull;
    // this.filterObj.SelectetdRecord = { cuauId: rowData.cuauId, cclNo: rowData.cclCode };
    /*if updating successful to unsccessful */
    if (!CommonUtilityService.checkCanLUpdateStatus(rowData.status, value.id as string)) {
      this.coreAlertService.showAlertPopup(GLOBAL_CONST.FEEDBACK_ITEM_MESSAGES.CONTACT_REG_APPROVER_MSG.split(';'));
    } else {
      this.showConfirmPopUpBeforeStatusUpdate();
    }
  }

  showConfirmPopUpBeforeStatusUpdate() {
    const options = { centered: true, windowClass: 'message-popup confirm-popup' };
    // tslint:disable-next-line:max-line-length
    const modalRef = this.coreAlertService.showConfirmPopup(GLOBAL_CONST.CONFIRM_STATUS_UPDATE_ALERT_TITLE, options);
    modalRef.result.then((data) => {
      this.callAPIToUpdateFBStatus();
    }, (reason) => {
      /* */
    });
  }
  callAPIToUpdateFBStatus() {
    this.dataService.updateFBStatus(this.filterObj, this.selectedRowObj.selectedRowId).subscribe((res: BaseResponseType) => {
      if (res.responseCode === EnumAPIResponseStatus.OK) {
        // this.filterObj.SelectetdRecord.data.status = CCLStatusType.Unsucessfull;
        this.filterObj.SelectetdRecord.data.status = CCLStatusType.Sucessfull;

        // tslint:disable-next-line:max-line-length
        this.coreAlertService.showSucessToasMessage(`Status of FB# ${formatNumber(this.filterObj.SelectetdRecord.data.fbNo, 'en-US', '3.0')} updated sucessfully.`);
      } else {
        // alert('error ' + res.responseMessage);
      }
    });
  }
  showFeedbackItemFullDetail(selectedRow: FeedbackItem) {
    const param: FbItemFullVwInputParam = {
      appName: this.selectedRowObj.appName,
      cclCode: this.selectedRowObj.cclNo,
      cclDes: this.selectedRowObj.cclDesc,
      cuauId: this.selectedRowObj.selectedRowId,
      fbId: selectedRow.fbId
    };
    // tslint:disable-next-line:max-line-length
    this.coreAlertService.showDynamicPopupWindow(FeedbaackItemFullVwComponent, { centered: true, windowClass: 'full-vw-pop', size: 'xl' }, param);
    //  const modalRef = this.modalService.open(FeedbaackItemFullVwComponent, { centered: true, windowClass: 'full-vw-pop', size: 'xl' });
  }
  closeFeedbackDetailView() {
    this.loadMainView.emit();
  }
  addNewFeedback() {
    this.showAddFeedbackPopUp();
  }
  showAddFeedbackPopUp() {
    const param: AddFbItemVwInputParam = {
      appName: this.selectedRowObj.appName,
      cclCode: this.selectedRowObj.cclNo,
      cclDes: this.selectedRowObj.cclDesc,
      cuauId: this.selectedRowObj.selectedRowId
    };
    // tslint:disable-next-line:max-line-length
    const modalRef = this.coreAlertService.showDynamicPopupWindow(AddFeedbackItemComponent, { centered: true, windowClass: 'confirm-st-pop', size: 'lg' }, param);
    // const modalRef = this.modalService.open(AddFeedbackItemComponent, { centered: true, windowClass: 'confirm-st-pop', size: 'lg' });
    modalRef.result.then((data) => {
      if (data) {
        alert('add new feedback');
        this.addNewFeedbackItem();
      }
    }, (reason) => {
      // alert('dismiss');
    });
  }
  addNewFeedbackItem() {
    // for (let i = 2; i < 3; i++) {
    const feedbackItem: FeedbackItem = {} as FeedbackItem;
    feedbackItem.fbId = 9;
    feedbackItem.status = CCLStatusType.Sucessfull;
    feedbackItem.stage = CCLStatusType.Unsucessfull;
    feedbackItem.fileName = 'new.jpg';
    feedbackItem.comment = 'this is new item';
  }

  setGridCoumns() {
    this.columnDefinitions = [
      {
        name: 'Status', field: 'status', sortable: true, colNo: 1, width: 100,
      },
      {
        name: 'F/B #', field: 'fbNo', sortable: true, width: 80, colNo: 2
      },
      { name: 'Comment', field: 'comment', sortable: true, colNo: 3 },
      { name: 'File', field: 'fileName', sortable: true, width: 150, colNo: 4 },
      {
        name: 'Stage', field: 'stage', sortable: true, colNo: 5, width: 100,
      },
      { name: 'Created', field: 'createdOn', sortable: true, width: 100, colNo: 6 },
      { name: 'Last Updated', field: 'updatedOn', sortable: true, width: 100, colNo: 7 },
      { name: 'Updated By', field: 'updatedBy', sortable: true, width: 100, colNo: 8 },
      {
        id: 'detail', name: '', field: '', width: 50, colNo: 9
      },
    ];
  }
  getFeedbackItems() {
    this.dataService.getFeedbackItems(this.filterObj, this.selectedRowObj.selectedRowId).subscribe((data: BaseResponseType) => {
      if (data.responseCode === EnumAPIResponseStatus.OK) {
        this.dt.filter(this.defaultStatusFilter.name, 'status', 'equals');
        this.dataset = data.data as FeedbackItem[];
      }
    });
  }
  filterFeedbackItemByStatus(dt: Table, $event, field) {
    dt.filter($event.value.name === 'All' ? null : $event.value.id, field, 'equals');
  }
}
class KeyValue {
  value: any;
  label: any;
}


