import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FeedbackItem, AddFbItemVwInputParam } from '../../../models/common.models';
import { FeedbackItemsService } from '../../services/feedback.items.service';

@Component({
  selector: 'app-add-upd-feedback-form',
  templateUrl: './add-update-feedback-form.component.html',
  // styleUrls: ['./add-update-feedback-form.component.scss']
})
export class AddUpdateFeedbackFormComponent implements OnInit {
  addFeedbackFrm: FormGroup;
  apiErrorMessage: '';
  @Input() data: AddFbItemVwInputParam;
  @Input() mode = 1;
  formGroupCls = 'col-12';
  @ViewChild('fileInput', { static: true }) fileInput;
  submitted = false;
  formObj = {
    comment: ['', Validators.required],
    attachement: ['']
  };

  constructor(private fb: FormBuilder, private model: NgbActiveModal, private service: FeedbackItemsService) {
    this.createForm();
  }
  ngOnInit() {
    if (+this.mode === 2) {
      this.formGroupCls = 'col-6';
    }
  }
  get f() {
    return this.addFeedbackFrm.controls;
  }
  createForm() {
    this.addFeedbackFrm = this.fb.group(this.formObj);
  }
  showHistoryVw() {
    alert('hi');
  }
  hideAPIError() {
    this.apiErrorMessage = '';
  }
  closePopUp() {

  }
  onSubmit() {

  }
  fileSelected(fileNameEle, fileUplloadEle) {
    // event.currentTarget.innerHTML = event.target.files[0].name;
    fileNameEle.innerHTML = fileUplloadEle.files[0].name;
  }
  addNewFeedback(fileControl) {
    this.submitted = true;
    if (this.addFeedbackFrm.valid) {
      const fileArr = fileControl; // .nativeElement;
      if (fileArr.files && fileArr.files[0]) {
        const comments = this.addFeedbackFrm.controls['comment'].value;
        const fileToUpload = fileArr.files[0];
        this.service.addFeedbackItem(this.addFeedbackFrm.controls.fileToUpload, this.data.cuauId).subscribe((res) => {
          console.log('response');
        });
        // this.uploadService
        //   .upload(fileToUpload)
        //   .subscribe(res => {
        //     console.log(res);
        //   });
      }
    }
    // const feedback: FeedbackItem = {} as FeedbackItem;
    // feedback.fileName = '';
    // feedback.comment = this.addFeedbackFrm.controls['comment'].value;
    // feedback.stage = '1';
    // feedback.status = '1';
    // feedback.fbId = 12;
    // this.model.close(feedback);
  }
  // this.apiErrorMessage = 'Error : Invalid Login, please try again.';
}


