import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddFeedbackItemComponent } from './add-feedback-item.component';

describe('AddFeedbackItemComponent', () => {
  let component: AddFeedbackItemComponent;
  let fixture: ComponentFixture<AddFeedbackItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddFeedbackItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddFeedbackItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
