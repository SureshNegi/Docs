import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FeedbackItem, AddFbItemVwInputParam } from '../../../models/common.models';

@Component({
  selector: 'app-add-feedback-item',
  templateUrl: './add-feedback-item.component.html',
  // styleUrls: ['./add-feedback-item.component.scss']
})
export class AddFeedbackItemComponent implements OnInit {
  @Input() data: AddFbItemVwInputParam;
  addFeedbackFrm: FormGroup;
  submitted = false;
  formObj = {
    comment: ['', Validators.required],
    attachement: ['']
  };
  constructor(private fb: FormBuilder, private model: NgbActiveModal) {
    this.createForm();
  }
  ngOnInit() {
  }
  get f() {
    return this.addFeedbackFrm.controls;
  }
  createForm() {
    this.addFeedbackFrm = this.fb.group(this.formObj);
  }
  submitFeedback() {
    this.submitted = true;
    if (this.addFeedbackFrm.valid) {
      const feedback: FeedbackItem = {} as FeedbackItem;
      feedback.fileName = '';
      feedback.comment = this.addFeedbackFrm.controls['comment'].value;
      feedback.stage = '1';
      feedback.status = '1';
      feedback.fbId = 12;
      this.model.close(feedback);
    }
    // this.apiErrorMessage = 'Error : Invalid Login, please try again.';
  }
  closeModel() {
    this.model.dismiss();
  }
}
