import { Component, OnInit, Output, EventEmitter, HostListener, ViewChild } from '@angular/core';
import { ApplicationService } from '../../services/application.service';
import { Observable, pipe, of } from 'rxjs';
import { catchError, map, tap, mergeMap } from 'rxjs/operators';
import { SelectList, CCLStatusType } from '../../../models/common.models';
import { GetFilterAPIResponse, DashboardDataAPIResponse, BaseResponseType } from '../../../models/api.models';
import { DataFilter, DashboardGirdAPIData, FilterType } from '../../../models/common.models';
import { CoreService } from '../../../core/core.service';
import { CoreAlertService } from '../../../core/core.alert.service';
import { EnumAPIResponseStatus } from '../../../core/api-response.model';
import { FeedbackItemPageParam } from '../../models/feedbackItem';
import * as GLOBAL_CONST from 'src/app/modules/models/global.const';
import { CommonUtilityService } from '../../services/common.utility.service';

@Component({
  selector: 'app-all-cclvw-grid',
  templateUrl: './all-cclvw-grid.component.html',
  // styleUrls: ['./all-cclvw-grid.component.scss']
})
export class AllCCLVwGridComponent implements OnInit {
  constructor(private appService: ApplicationService, private coreAlertService: CoreAlertService) { }
  columnDefinitions = [];
  confirmPopTitle = `Confirm status update`;
  selectedCCLStatusOptOnEditMode: FilterType = {} as FilterType;
  appFilterDataSource: Observable<any[]>;
  typeOptions: Observable<any[]>;
  statusEditOptions: any;
  filterObj: DataFilter = null;
  // appFilterDataSource: any[];
  @ViewChild('grid', { static: true }) gridObj;
  @Output() loadFeedbackDetailsEvent = new EventEmitter();
  cclTypes = ['Enhancement', 'Fix', 'Maintenance'];
  statusFilterOptions: FilterType[] = GLOBAL_CONST.STATUS_FILTER_OPTIONS;
  retestOptions = [{ value: '', label: 'All' }, { value: 'Yes', label: 'Yes' }, { value: 'No', label: 'No' }];
  dataSet: any[] = [];
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    // setTimeout(() => { this.gridObj.scrollHeight = '250px'; }, 1000);
    this.gridObj.scrollHeight = '250px';
  }
  editInit(args) {
    const editingRow: DashboardGirdAPIData = args.data;
    this.selectedCCLStatusOptOnEditMode = {} as FilterType;
    this.selectedCCLStatusOptOnEditMode.id = editingRow.cclStatus;
  }
  sorting(e) {

  }


  ngOnInit() {
    this.filterObj = new DataFilter(0, CCLStatusType.Unsucessfull, 'appName', CoreService.getEmpNo());
    this.getAllAppsToBindAppFilterDataSourse();
    this.getDashboardData();
    localStorage.setItem(
      'statedemo-local',
      '{"columnWidths":"250,200,400,250"}'
    );
    this.columnDefinitions = [
      {
        name: 'Application', field: 'appName', sortable: true, filterable: true, colNo: 1, filter: true
      },
      {
        name: 'Status', field: 'cclStatus', sortable: true, filterable: true, colNo: 2, filter: true
      },
      { name: 'CCL#', field: 'cclCode', sortable: true, colNo: 3, width: 50 },
      { id: 'type', name: 'Type', field: 'cclType', colNo: 4, width: 80 },
      { id: 'cepCode', name: 'CEP Code', field: 'cepCode', colNo: 5 },
      {
        name: 'CCL Description', field: 'cclDes', sortable: true, minWidth: 350, width: 350, maxWidth: 350, colNo: 6
      },
      { name: 'Date Released', field: 'releaseDate', sortable: true, colNo: 7 },
      {
        name: 'Pending Retest', field: 'pendingRetest', sortable: true, filterable: true, colNo: 8
      },

      { name: 'Feedback Summary', field: 'totalFBCount', sortable: false, width: 150, colNo: 9, filter: true },
      {
        name: '', field: 'openSDR', minWidth: 50, width: 50, maxWidth: 50, colNo: 10
      },
    ];
    this.setWidth();
    // this.bindGridDatasource([]);
  }
  updateCCLStatus(value: FilterType, rowData: DashboardGirdAPIData) {
    this.filterObj.SelectetdRecord = { id: rowData.cuauId, cclNo: rowData.cclCode, data: rowData };
    /*if updating successful to unsccessful */
    if (CommonUtilityService.checkCanLUpdateCCL(rowData.cclStatus, value.id as string)) {
      this.coreAlertService.showAlertPopup(GLOBAL_CONST.MAIN_PAGE_MESSSGES.CONTACT_REG_APPROVER_MSG.split(';'));
      // tslint:disable-next-line:max-line-length
    } /*if all sdr not closed and updating to sucessful*/  else if (CommonUtilityService.checkIsToShowConfirmationMsg(rowData.isAllSdrNotClosed, value.id as string)) {
      this.showConfirmPopUpBeforeStatusUpdate();
    } else {
      this.callAPIToUpdateCCLStatus();
    }
  }
  showConfirmPopUpBeforeStatusUpdate() {
    const options = { centered: true, windowClass: 'message-popup confirm-popup' };
    const msgList = GLOBAL_CONST.MAIN_PAGE_MESSSGES.CONFIRM_MSG_BEFORE_STATUS_UPDATE.split(';');
    // tslint:disable-next-line:max-line-length
    const modalRef = this.coreAlertService.showConfirmPopup(this.confirmPopTitle, options, msgList);
    modalRef.result.then((data) => {
      this.callAPIToUpdateCCLStatus();
    }, (reason) => {
      /* */
    });
  }
  callAPIToUpdateCCLStatus() {
    this.appService.updateCCLStatus(this.filterObj).subscribe((res: BaseResponseType) => {
      if (res.responseCode === EnumAPIResponseStatus.OK) {
        this.filterObj.SelectetdRecord.data.cclStatus = CCLStatusType.Sucessfull;
        this.coreAlertService.showSucessToasMessage(`Status of CCL# ${this.filterObj.SelectetdRecord.cclNo} updated successfully.`);
      } else {
        // alert('error ' + res.responseMessage);
      }
    });
  }
  getDashboardData() {
    this.appService.getDashboardIData(this.filterObj).subscribe((data: DashboardDataAPIResponse) => {
      this.bindGridDatasource(data.data);
    });
  }
  appFilterUpdate(value) {
    this.getDashboardData();
  }
  cclStatusFilterUpdate(value) {
    console.log(this.filterObj.Status);
    // this.filterObj.Status = value.id;
    this.getDashboardData();
  }
  getAllAppsToBindAppFilterDataSourse() {
    // const filterApiResponse = this.appService.getAllAppsInfo(this.filterObj.EmplNo);
    // this.appFilterDataSource = filterApiResponse.pipe(map((data: GetFilterAPIResponse) => {
    //   return data.data.appType;
    // }));
    // this.typeOptions = filterApiResponse.pipe(map((data: GetFilterAPIResponse) => {
    //   return data.data.cclType;
    // }));
    const filterApiResponse = this.appService.getAllAppsInfo(this.filterObj.EmplNo);
    // filterApiResponse.source.pipe
    this.appFilterDataSource = filterApiResponse.pipe(map((data: GetFilterAPIResponse) => {
      this.typeOptions = of(data.data.cclType);
      return data.data.appType;
    }));
    // this.typeOptions = filterApiResponse.source.pipe(map((data: GetFilterAPIResponse) => {
    //   return data.data.cclType;
    // }));
    this.statusEditOptions = this.statusFilterOptions.filter((item: FilterType) => {
      return item.id !== CCLStatusType.All;
    });
  }
  changeType(d) {
    console.log(d);
  }
  setWidth() {
    this.columnDefinitions.forEach(c => {
      c.width = c.width ? c.width : 'auto';
    });
  }
  onRowSelect(e) {
    console.log(e);
    return false;
  }
  showDetails(selectedRow: DashboardGirdAPIData) {
    // this.coreAlertService.showSucessToasMessage('CCL 9205, status updated to Sucessful.');
    this.loadFeedbackDetailsEvent.emit({
      selectedRowId: selectedRow.cuauId,
      appName: selectedRow.appName,
      cclNo: selectedRow.cclCode,
      cclDesc: selectedRow.cclDes,
      empNo: CoreService.getEmpNo()
    } as FeedbackItemPageParam);
  }
  bindGridDatasource(data: DashboardGirdAPIData[]) {
    this.dataSet = data;
  }
}
enum FilterId {
  AllApp = 1,
  StatusAll = 2
}

