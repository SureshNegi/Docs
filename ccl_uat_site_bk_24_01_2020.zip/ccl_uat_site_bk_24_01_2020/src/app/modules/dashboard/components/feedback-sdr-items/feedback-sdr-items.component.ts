import { Component, OnInit, EventEmitter, Output, Input, OnChanges } from '@angular/core';
import { AddFeedbackItemComponent } from '../add-feedback-item/add-feedback-item.component';
import { FeedbaackItemFullVwComponent } from '../feedbaack-item-full-vw/feedbaack-item-full-vw.component';
import * as GLOBAL_CONST from 'src/app/modules/models/global.const';
import { CCLStatusType, FilterType, FeedbackSDRItem } from '../../../models/common.models';

@Component({
  selector: 'app-fb-sdr-data-grid',
  templateUrl: './feedback-sdr-items.component.html',
  // styleUrls: ['./data-grid.component.scss']
})
export class FeedbackSdrItemsComponent implements OnInit, OnChanges {
  @Input() columnDefinitions: any[] = [];
  @Input() dataset: any[] = [];
  @Input() grdId = '';
  @Input() availableHeightForGrid = 100;
  statusEditOptions: typeof GLOBAL_CONST.STATUS_FILTER_OPTIONS;
  selectedStatusOptOnEditMode: FilterType;
  constructor() { }
  ngOnInit() {
    this.statusEditOptions = GLOBAL_CONST.STATUS_FILTER_OPTIONS.filter((item: FilterType) => {
      return item.id !== CCLStatusType.All;
    });
  }
  ngOnChanges() {
    console.log(this.columnDefinitions);
  }
  updateSDRStatus(toValue, selectedRow) {

  }
  editInit(args) {
    // this.selectedStatusOptOnEditMode = { id: args.data.status } as FilterType;
    const editingRow: FeedbackSDRItem = args.data;
    this.selectedStatusOptOnEditMode = {} as FilterType;
    this.selectedStatusOptOnEditMode.id = editingRow.markedAs;
  }
}



