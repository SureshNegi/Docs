import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailCellTemplateComponent } from './grd-detail-cell-template.component';

describe('SlickGridAngularComponenForDetailComponent', () => {
  let component: DetailCellTemplateComponent;
  let fixture: ComponentFixture<DetailCellTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailCellTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailCellTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
