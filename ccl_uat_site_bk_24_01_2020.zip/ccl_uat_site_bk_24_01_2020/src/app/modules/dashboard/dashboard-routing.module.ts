import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardVwComponent } from './dashboard-vw.component';
import { AuthGuard } from '../core/auth.guard';

const dashboardRoutes: Routes = [
  {
    path: '',
    component: DashboardVwComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'feedBackItems',
    component: DashboardVwComponent,
    canActivate: [AuthGuard],
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(dashboardRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class DashboardRoutingModule { }

