import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardVwComponent } from './dashboard-vw.component';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { SharedModule } from '../shared/shared.module';
import { PrimengModuleProvider } from './primeng.module';
import { CCLStatusPipe } from './pipes/status.pipe';
import { ReleasedDatePipe } from './pipes/date.pipe';

import { HeaderComponent } from './components/header/header.component';
import { AllCCLVwGridComponent } from './components/all-cclvw-grid/all-cclvw-grid.component';
import { DetailCellTemplateComponent } from './components/grd-detail-cell-template/grd-detail-cell-template.component';
import { FeedbackItemsComponent } from './components/feedback-items-details/feedback-items-details.component';
import { AddFeedbackItemComponent } from './components/add-feedback-item/add-feedback-item.component';
import { NgbModule, NgbDropdownModule, NgbTooltipModule, NgbModalModule, NgbTabsetModule } from '@ng-bootstrap/ng-bootstrap';
import { AddUpdateFeedbackFormComponent } from './components/add-update-feedback-form/add-update-feedback-form.component';
import { FeedbaackItemFullVwComponent } from './components/feedbaack-item-full-vw/feedbaack-item-full-vw.component';
import { DataGridComponent } from './components/data-grid/data-grid.component';
import { FeedbackSdrItemsComponent } from './components/feedback-sdr-items/feedback-sdr-items.component';

const bootStratModules = [NgbModule, NgbDropdownModule, NgbTooltipModule, NgbModalModule, NgbTabsetModule];
@NgModule({
  // tslint:disable-next-line:max-line-length
  declarations: [DataGridComponent, FeedbackSdrItemsComponent, FeedbackItemsComponent, FeedbaackItemFullVwComponent, AddUpdateFeedbackFormComponent, CCLStatusPipe, ReleasedDatePipe, AddFeedbackItemComponent,
    DetailCellTemplateComponent, DashboardVwComponent, HeaderComponent, AllCCLVwGridComponent],
  imports: [SharedModule, CommonModule, DashboardRoutingModule,
    PrimengModuleProvider, bootStratModules
  ],
  exports: [DashboardVwComponent, AddFeedbackItemComponent, FeedbaackItemFullVwComponent],
  entryComponents: [AddFeedbackItemComponent, FeedbaackItemFullVwComponent]
})
export class DashboardModule { }
