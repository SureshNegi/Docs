import { Pipe, PipeTransform } from '@angular/core';
import { CCLStatusType } from '../../models/common.models';
import * as moment from 'moment';

@Pipe({
  name: 'relsdDate'
})
export class ReleasedDatePipe implements PipeTransform {

  transform(d: any): any {
    const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    let dParts = d.split('T'); // 2017-01-09T14:43:14
    dParts = d[0].split('-'); // 2017-01-09
    return moment(d).format('DD-MMM-YY');

  }

}
