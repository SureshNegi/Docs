import { Pipe, PipeTransform } from '@angular/core';
import { CCLStatusType } from '../../models/common.models';

@Pipe({
  name: 'cclStatus'
})
export class CCLStatusPipe implements PipeTransform {

  transform(value: any): any {
    return (value === CCLStatusType.Unsucessfull) ? 'Unsucessfull' : 'Sucessfull';
  }

}
