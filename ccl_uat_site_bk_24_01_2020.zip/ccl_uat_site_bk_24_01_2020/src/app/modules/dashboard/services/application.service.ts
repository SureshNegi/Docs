import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, mergeMap } from 'rxjs/operators';
// import { APIBaseAddress } from '../../core/app-config';
import { APINames } from '../../core/api-url.config';
import { AuthService } from '../../core/auth.service';
import * as  APIResTypes from '../../models/api.models';
import { EnumAPIResponseStatus } from '../../core/api-response.model';
import { delay } from 'rxjs/internal/operators';
import { Observable, of, from } from 'rxjs';
import { concatMap } from 'rxjs/internal/operators';
import { CookieService } from 'ngx-cookie-service';
const apiParamPrefix = 'I_JSON';
import { LoaderService } from '../../shared/loader.service';
import { DataFilter } from 'src/app/modules/models/common.models';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class ApplicationService {
    redirectUrl: string;
    constructor(private loaderService: LoaderService, private httpClient: HttpClient, private cookieService: CookieService) { }
    getAllAppsInfo(empNo): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.getAppsInfo}`;
        const header = new HttpHeaders().set('emplNo', empNo);
        const p = { emplNo: empNo };
        return this.httpClient.get<APIResTypes.BaseResponseType>(apiURL, { params: p, headers: header }).pipe(map(apiObj => {
            return this.parseGetAllAppsInfoResp(apiObj);
        }));
        // const obj = { responseCode: 0, responseMessage: '', data: [{ appId: 1, appName: 'App1' }] };
        // const fakeObservable = of(obj).pipe(delay(1000));
        // fakeObservable.subscribe(() => {
        //     this.loaderService.isLoading.next(false);
        // });
        // return fakeObservable;

    }
    getDashboardIData(filterObj: DataFilter): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.getDashboardData}`;
        const paramObj = {
            emplNo: filterObj.EmplNo, appId: filterObj.App.id, cclStatus: filterObj.Status.id
        };
        return this.httpClient.post<APIResTypes.BaseResponseType>(apiURL, paramObj).pipe(map(apiObj => {
            console.log('data.........');
            console.log(apiObj);
            return this.parsDashboardDataResultFromAPI(apiObj);
        }));
    }
    updateCCLStatus(filterObj: DataFilter): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.getDashboardData}`;
        const paramObj = {
            emplNo: +filterObj.EmplNo, cuauId: filterObj.SelectetdRecord.id
        };
        // const header = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded');
        return this.httpClient.put<APIResTypes.BaseResponseType>(apiURL,  paramObj).pipe(map(apiObj => {
            return apiObj;
        }));
    }
    parseGetAllAppsInfoResp(apiObj: any): APIResTypes.BaseResponseType {
        const repObj: APIResTypes.GetFilterAPIResponse = { data: { cclType: [], appType: [] } } as APIResTypes.GetFilterAPIResponse;
        repObj.responseCode = +apiObj.responseCode;
        repObj.responseMessage = apiObj.responseMessage;
        if (repObj.responseCode === EnumAPIResponseStatus.OK) {
            repObj.data.cclType = apiObj.cclType;
            repObj.data.appType = apiObj.appType;
        }
        return repObj;
    }
    parsDashboardDataResultFromAPI(apiObj: APIResTypes.BaseResponseType): APIResTypes.BaseResponseType {
        // const repObj: APIResTypes.DashboardDataAPIResponse = {
        //     responseCode: +apiObj.responseCode,
        //     responseMessage: apiObj.responseMessage,
        //     data: apiObj.data
        // } as APIResTypes.DashboardDataAPIResponse;
        const repObj: APIResTypes.BaseResponseType = apiObj;
        return repObj;
    }
}




