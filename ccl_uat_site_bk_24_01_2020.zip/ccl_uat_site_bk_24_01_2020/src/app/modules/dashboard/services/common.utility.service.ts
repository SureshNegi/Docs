
import { DataFilter, CCLStatusType } from '../../models/common.models';

export class CommonUtilityService {
    static checkCanLUpdateCCL(currentValue: string, toValue: string): boolean {
        let result = true;
        if (currentValue === CCLStatusType.Sucessfull && toValue === CCLStatusType.Unsucessfull) {
            result = false;
        }
        return result;
    }
    static checkCanLUpdateStatus(currentValue: string, toValue: string): boolean {
        return CommonUtilityService.checkCanLUpdateCCL(currentValue, toValue);
    }
    static checkIsToShowConfirmationMsg(openCount: boolean, toValue: string): boolean {
        let result = false;
        if (toValue === CCLStatusType.Sucessfull && openCount) {
            result = true;
        }
        return result;
    }
}
