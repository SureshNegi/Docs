import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map, tap, mergeMap } from 'rxjs/operators';
// import { APIBaseAddress } from '../../core/app-config';
import { APINames } from '../../core/api-url.config';
import { AuthService } from '../../core/auth.service';
import * as  APIResTypes from '../../models/api.models';
import { EnumAPIResponseStatus } from '../../core/api-response.model';
import { delay } from 'rxjs/internal/operators';
import { Observable, of, from } from 'rxjs';
import { concatMap } from 'rxjs/internal/operators';
import { CookieService } from 'ngx-cookie-service';
const apiParamPrefix = 'I_JSON';
import { LoaderService } from '../../shared/loader.service';
import { BaseDataFilter, DataFilter } from 'src/app/modules/models/common.models';
import { environment } from 'src/environments/environment';

@Injectable({
    providedIn: 'root'
})
export class FeedbackItemsService {
    redirectUrl: string;
    constructor(private loaderService: LoaderService, private httpClient: HttpClient, private cookieService: CookieService) { }
    addFeedbackItem(fileToUpload: any, cuauValue): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.file}`;
        const formData = new FormData();
        formData.append('file', fileToUpload);
        const paramObj = {
            // emplNo: filterObj.EmplNo, cuauId: cuauValue, fbStatus: filterObj.Status.id
        };
        return this.httpClient.post<APIResTypes.BaseResponseType>(apiURL, paramObj).pipe(map(apiObj => {
            return apiObj;
        }));
    }

    getFeedbackItems(filterObj: BaseDataFilter, cuauValue): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.feedbackItems}`;
        const paramObj = {
            emplNo: filterObj.EmplNo, cuauId: cuauValue, fbStatus: filterObj.Status.id
        };
        return this.httpClient.post<APIResTypes.BaseResponseType>(apiURL, paramObj).pipe(map(apiObj => {
            return apiObj;
        }));
    }
    getFeedbackItemHistory(param: { cuauValue: number, fbId: number }): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.feedbackItemHistory}`;
        const paramString = new HttpParams()
            .set('cuauId', `${param.cuauValue}`)
            .set('fbId', `${param.fbId}`);
        return this.httpClient.get<APIResTypes.BaseResponseType>(apiURL, { params: paramString }).pipe(map(apiObj => {
            return apiObj;
        }));
    }
    getFeedbackItemSDRs(param: { cuauValue: number, fbId: number }): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.feedbackSDRItems}`;
        const paramString = new HttpParams()
            .set('cuauId', `${param.cuauValue}`)
            .set('fbId', `${param.fbId}`);
        return this.httpClient.get<APIResTypes.BaseResponseType>(apiURL, { params: paramString }).pipe(map(apiObj => {
            return apiObj;
        }));
    }
    updateFBStatus(filterObj: BaseDataFilter, cclUatId): Observable<APIResTypes.BaseResponseType> {
        const apiURL = `${environment.apiBaseURL}${APINames.feedbackItems}`;
        const paramObj = {
            emplNo: +filterObj.EmplNo, cuauId: cclUatId, cuaFbId: filterObj.SelectetdRecord.id
        };
        // const header = new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded');
        return this.httpClient.put<APIResTypes.BaseResponseType>(apiURL, paramObj).pipe(map(apiObj => {
            return apiObj;
        }));
    }
}




