import { Component, OnInit } from '@angular/core';
import { AuthService } from '../core/auth.service';
import { ApplicationService } from './services/application.service';
import { Router } from '@angular/router';
import { CoreService } from '../core/core.service';
import { LoaderService } from '../shared/loader.service';

@Component({
  selector: 'app-dashboard-vw',
  templateUrl: './dashboard-vw.component.html',
  // styleUrls: ['./dashboard-vw.component.scss']
})
export class DashboardVwComponent implements OnInit {
  cclView = false;
  selectedRowObj;
  empDisplayName = '';
  constructor(private authService: AuthService, private appService: ApplicationService, private router: Router) { }

  ngOnInit() {
    this.empDisplayName = CoreService.getEmpDisplayName();
  }
  signOut() {
    this.authService.employeeLogout('').subscribe((data) => {
      this.router.navigate(['login']);
    });
  }
  showFeedbackDetailView(args: { selectedRow: 0 }) {
    this.selectedRowObj = args;
    this.cclView = true;
  }
  showMainView() {
    this.cclView = false;
  }

}
