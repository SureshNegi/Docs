import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../core/auth.service';
import { LoginAPIResponse, EnumAPIResponseStatus } from '../core/api-response.model';
import { Router, CanActivate } from '@angular/router';
import { CoreService } from '../core/core.service';



@Component({
  selector: 'app-login-vw',
  templateUrl: './login-vw.component.html',
  // styleUrls: ['./login-vw.component.scss']
})
export class LoginComponent implements OnInit {
  lgnForm: FormGroup;
  submitted = false;
  apiErrorMessage: string;
  formObj = {
    name: ['', Validators.required],
    password: ['', Validators.required]
  };
  constructor(coreService: CoreService, public router: Router, private fb: FormBuilder, private authService: AuthService) {
    this.createForm();
    coreService.setApplicationConfigurations();
  }
  get f() {
    return this.lgnForm.controls;
  }
  hideAPIError() {
    this.apiErrorMessage = '';
  }
  createForm() {
    this.lgnForm = this.fb.group(this.formObj);
  }
  ngOnInit() {

  }

  onSubmit() {
    this.submitted = true;
    if (this.lgnForm.valid) {
      // this.lgnForm.controls.get()
      // this.authService.employeeLogin(){
      const userName = this.lgnForm.controls['name'].value;
      const passwd = this.lgnForm.controls['password'].value;
      console.log(userName);
      this.authService.employeeLogin(userName, passwd).subscribe((apiResp: LoginAPIResponse) => {
        if (apiResp.responseCode === EnumAPIResponseStatus.OK) {
          this.router.navigate(['dashboard']);
        } else {
          this.apiErrorMessage = apiResp.responseMessage;
        }
      }, err => {
        if (err.status === 500) {
          // alert('500 error');
        } else {
          this.apiErrorMessage = (err.statusText ? err.statusText : 'Error on calling API.');
        }
      });
    }
    // this.apiErrorMessage = 'Error : Invalid Login, please try again.';
  }
  testApi() {
    this.authService.testApi().subscribe((apiResp: LoginAPIResponse) => {
      console.log(apiResp);
    });
  }

}
