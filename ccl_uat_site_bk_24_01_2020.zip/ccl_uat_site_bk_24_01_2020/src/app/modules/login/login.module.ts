import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login-vw.component';
import { LoginRoutingModule } from './login-routing.module';
import { LoginHeaderComponent } from './components/header/header.component';
import { SharedModule } from '../shared/shared.module';
import { FooterComponent } from './components/footer/footer.component';



@NgModule({
  declarations: [LoginComponent, LoginHeaderComponent, FooterComponent],
  imports: [
    CommonModule, LoginRoutingModule, SharedModule
  ],
  exports: [LoginComponent]
})
export class LoginModule { }
