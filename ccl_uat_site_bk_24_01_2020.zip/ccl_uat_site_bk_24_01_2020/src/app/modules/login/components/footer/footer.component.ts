import { Component, OnInit } from '@angular/core';
import { CoreMessageService } from '../../../core/core-message.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { WebConfigObj } from '../../../core/api-response.model';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  // styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  appversion: Observable<any>;
  constructor(private messageService: CoreMessageService) {
    this.appversion = this.messageService.getAppConfiguration().pipe(map((data: WebConfigObj) => {
      return data.APP_VERSION;
    }));
  }

  ngOnInit() {
  }

}
