import { FilterType, DashboardGirdAPIData, CCLStatusType } from './common.models';

export const CONFIRM_STATUS_UPDATE_ALERT_TITLE = 'Confirm status update';
export const STATUS_FILTER_OPTIONS: FilterType[] = [
    { id: CCLStatusType.All, name: 'All' },
    { id: CCLStatusType.Sucessfull, name: 'Sucessfull' },
    { id: CCLStatusType.Unsucessfull, name: 'Unsucessfull' }
];
export const STAGE_FILTER_OPTIONS: FilterType[] = [
    { id: '', name: 'All' },
    { id: 'Closed', name: 'Closed' },
    { id: 'Pending MCIS', name: 'Pending MCIS' }
];
export const MAIN_PAGE_MESSSGES = {
    // tslint:disable-next-line:max-line-length
    CONFIRM_MSG_BEFORE_STATUS_UPDATE: `There are unresolved feedback(s) associated with this CCL you are updating to stage Successful.;All unsuccessful feedback(s) will be marked as Closed.;`,
    // tslint:disable-next-line:max-line-length
    CONTACT_REG_APPROVER_MSG: `You have already marked this item as Successful.;Please contact the Regional Approver should you need to change the status back to Unsuccessful.`
};
export const FEEDBACK_ITEM_MESSAGES = {
    // tslint:disable-next-line:max-line-length
    CONTACT_REG_APPROVER_MSG: `This feedback has already been marked as Successful.;Please submit unsuccessful feedback as new feedback items.;Should you need to reopen this feedback item, please contact the Regional Approver.`
}


