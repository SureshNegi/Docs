interface KeyValue {
    value: any;
    label: string;
}
export enum CCLStatusType { All = 'All', Unsucessfull = 'O', Sucessfull = 'C', }
export class EmployeeInfo {
    displayName: string;
    empNo: number;
}
export class FilterType {
    id: string | number;
    name: string;
}
export class SelectList implements KeyValue {
    value: any;
    label: string;
}
export class BaseDataFilter {
    EmplNo: number;
    Status: FilterType;
    SortField: string;
    SelectetdRecord: { id: number, cclNo: number, data?: any };
    constructor(empNo, sortBy, status?: FilterType) {
        this.EmplNo = empNo;
        this.Status = status;
        this.SortField = sortBy;
    }
}
export class DataFilter extends BaseDataFilter {
    App: FilterType;

    // SelectetdCUAUID: number;

    constructor(appId, statusId: string, sortBy, empId) {
        super(empId, sortBy);
        this.App = { id: appId, name: 'All' } as FilterType;
        this.Status = { id: statusId, name: 'Unsucessfull' } as FilterType;
    }
}

export class DashboardGirdAPIData {
    appId: number;
    appCode: string;
    appName: string;
    cclCode: number;
    cepCode: string;
    cclDes: string;
    releaseDate: string;
    cuauId: number;
    cclLinkUrl: string;
    cclStatus: string;
    cclType: string;
    pendingRetest: string;
    pendingTestFBCount: number;
    pendingMfsFBCount: number;
    rejectedMfsFBCount: number;
    totalFBCount: number;
    isAllSdrNotClosed: boolean;
}
export class FeedbackItem {
    fbId: number;
    status: string;
    fbNo: string;
    comment: string;
    fileName: string;
    fileLinkURL: string;
    stage: string;
    createdOn: string;
    updatedOn: string;
    updatedBy: string;
}
export class FeedbackSDRItem {
    cuauId: number;
    fbId: number;
    sdrNo: string;
    desc: string;
    status: string;
    markedAs: string;
}
export class AddFbItemVwInputParam {
    appName: string;
    cuauId: number;
    cclCode: number;
    cclDes: string;
}
export class FbItemFullVwInputParam {
    appName: string;
    cuauId: number;
    cclCode: number;
    cclDes: string;
    fbId: number;
}

