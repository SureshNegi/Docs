import { IAPIResponse, EnumAPIResponseStatus } from '../core/api-response.model';
import { FilterType, DashboardGirdAPIData } from './common.models';


// export enum ResponseTypes {
//     OK = 0,
//     Error = 1,
//     InvalidSession = 2,
//     LogginFail = 3,
// }
export interface BaseResponseType extends IAPIResponse {
    data: any;
}
export interface GetFilterAPIResponse extends BaseResponseType {
    data: {
        cclType: FilterType[];
        appType: FilterType[];
    };
}
export interface DashboardDataAPIResponse extends BaseResponseType {
    data: DashboardGirdAPIData[];
}
