import { NgModule, ModuleWithProviders } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './auth.service';
import { CookieService } from 'ngx-cookie-service';

import { NgbModule, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
const bootStratModules = [NgbModule, NgbModalModule];
@NgModule({
  imports: [
    HttpClientModule, bootStratModules
  ],
  declarations: [],
  providers: [
    AuthService,
    CookieService
  ],
  exports: [],
  entryComponents: []
})
export class CoreModule {
}
