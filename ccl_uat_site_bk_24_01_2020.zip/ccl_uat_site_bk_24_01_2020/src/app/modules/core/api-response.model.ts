import { EmployeeInfo } from '../models/common.models';
export interface IAPIResponse {
    responseCode: EnumAPIResponseStatus;
    responseMessage: string;
    data: any;
}
export enum EnumAPIResponseStatus {
    OK = 0,
    Error = 1,
    InvalidSession = 2,
    LogginFail = 3,
}
export class WebConfigObj {
    API_BASE_URL: string;
    APP_VERSION: string;
    APP_TITLE: string;
}
export interface LoginAPIResponse extends IAPIResponse {
    responseCode: EnumAPIResponseStatus;
    responseMessage: string;
    data: {
        sessionId: string; empInfo: EmployeeInfo
    };
}
