import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CoreMessageService {
  private subject = new Subject<any>();
  private messageSubject = new Subject<any>();

  sendMessage(message: string, type: EnumMessageType) {
    this.messageSubject.next({ Message: message, Type: type });
    //this.messageSubject.next({ text: message });
  }

  clearMessage() {
    this.subject.next();
  }

  getMessage(): Observable<any> {
    return this.messageSubject.asObservable();
  }
  sendAppConfiguration(appConfig: any) {
    this.subject.next(appConfig);
  }
  getAppConfiguration(): Observable<any> {
    return this.subject.asObservable();
  }
}

export class MessageObj {
  Message: string;
  Type: EnumMessageType;
}
export enum EnumMessageType { SucessToastMessage = 1 }
