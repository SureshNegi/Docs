import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { WebConfigFilePath } from './app-config';
import { environment } from 'src/environments/environment';
import { CoreMessageService } from './core-message.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { WebConfigObj } from './api-response.model';

@Injectable({
    providedIn: 'root'
})
export class CoreService {
    static AUTH_LS_KEY = 'userAuthTokenDetail';
    static COOKIES_SERVICE_OBJ: CookieService;
    constructor(private http: HttpClient, private modalService: NgbModal, private messageService: CoreMessageService) {
        this.setApplicationConfigurations();
    }
    static saveUserTokeninfo(data: UserAuthTokenDetail) {
        this.COOKIES_SERVICE_OBJ.set(this.AUTH_LS_KEY, JSON.stringify(data));
        localStorage.setItem(this.AUTH_LS_KEY, JSON.stringify(data));
    }
    static getUserTokenInfo() {
        if (this.COOKIES_SERVICE_OBJ) {
            return this.COOKIES_SERVICE_OBJ.get(this.AUTH_LS_KEY);
        } else {
            return '';
        }
    }
    static getAuthToken(): string {
        if (this.COOKIES_SERVICE_OBJ) {
            const objString = this.COOKIES_SERVICE_OBJ.get(this.AUTH_LS_KEY);
            const lsObj: UserAuthTokenDetail = objString ? JSON.parse(objString) : { AuthToken: '' };
            return lsObj.AuthToken;
        } else {
            return '';
        }
    }
    static getEmpNo(): number {
        if (this.COOKIES_SERVICE_OBJ) {
            const objString = this.COOKIES_SERVICE_OBJ.get(this.AUTH_LS_KEY);
            const lsObj: UserAuthTokenDetail = objString ? JSON.parse(objString) : { LoginId: 0 };
            return lsObj.LoginId;
        } else {
            return 0;
        }
    }
    static getEmpDisplayName(): string {
        const authObj: UserAuthTokenDetail = { AuthToken: '', LoginId: 0, DisplayEmpName: '' };
        if (this.COOKIES_SERVICE_OBJ) {
            const objString = this.COOKIES_SERVICE_OBJ.get(this.AUTH_LS_KEY);
            const lsObj = objString ? JSON.parse(objString) : authObj;
            return lsObj.DisplayEmpName;
        } else {
            return '';
        }
    }
    static clearUserSession() {
        localStorage.removeItem(this.AUTH_LS_KEY);
    }
    setApplicationConfigurations() {
        this.http.get(WebConfigFilePath).subscribe((data: WebConfigObj) => {
            this.messageService.sendAppConfiguration(data);
            environment.apiBaseURL = data.API_BASE_URL;
            environment.appVersion = data.APP_VERSION;
            environment.appTitile = data.APP_TITLE;
        });
    }
}

export class CoreServices {
}

export class UserAuthTokenDetail {
    AuthToken: string;
    LoginId: number;
    DisplayEmpName: string;
}



