export const APINames = {
    lookupCEPCode: 'te_html5_htp_pkg.lookupCEPCode',
    loadCEPCodeDetails: 'te_html5_htp_pkg.loadCEPCodeDetails',
    empLogin: 'api/login',
    getAppsInfo: 'api/application',
    getDashboardData: 'api/cclData',
    feedbackItems: 'api/feedbackItems',
    file: 'api/apiFile',
    feedbackSDRItems: 'api/feedback/sdrs',
    feedbackItemHistory: 'api/feedbackItem/History',
    retrieveInitialData: 'te_html5_htp_pkg.retrieveInitialData',
    loadRevenueMonths: 'te_html5_htp_pkg.loadRevenueMonths'
};
