// loader.interceptors.ts
import { Injectable } from '@angular/core';
import {
    HttpErrorResponse,
    HttpResponse,
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
import { CoreService, UserAuthTokenDetail } from '../core/core.service';
import { LoaderService } from '../shared/loader.service';
import { finalize, catchError, map, } from 'rxjs/operators';
@Injectable()
export class LoaderInterceptor implements HttpInterceptor {
    static requestsCount = 0;
    constructor(public loaderService: LoaderService) { }
    removeRequest(req: HttpRequest<any>) {
        console.log('before--->>>', LoaderInterceptor.requestsCount);
        --LoaderInterceptor.requestsCount;
        this.checkForHideLoader();
    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const checkKey = 'authorization';
        const token: string = CoreService.getAuthToken();
        if (token) {
            request = request.clone({ headers: request.headers.set(checkKey, token) });
        }

        if (!request.headers.has('Content-Type')) {
            request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
        }

        request = request.clone({ headers: request.headers.set('Accept', 'application/json') });
        ++LoaderInterceptor.requestsCount;
        console.log('requestsCount--->>>', LoaderInterceptor.requestsCount);
        return next.handle(request).pipe(
            map((event: HttpEvent<any>) => {
                !this.loaderService.isLoading.getValue() && this.loaderService.isLoading.next(true);
                if (event instanceof HttpResponse) {
                    this.removeRequest(request);
                }
                // if (event instanceof ErrorEvent) {
                //     alert('error type');
                // }
                return event;
            })
            // catchError((error: HttpErrorResponse) => {
            //     console.log('error on api call');
            //     let errorMessage = '';
            //     if (error.error instanceof ErrorEvent) {
            //         // client-side error
            //         errorMessage = `Error: ${error.error.message}`;
            //     } else {
            //         // server-side error
            //         errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
            //     }
            //     return throwError(errorMessage);
            // })
        );
    }
    checkForHideLoader() {
        setTimeout(
            () => {
                if (LoaderInterceptor.requestsCount <= 0) {
                    LoaderInterceptor.requestsCount = 0;
                    this.loaderService.isLoading.next(false);
                }
            }, 500
        );
    }
}
