export const CEPCodeMaskInfo = { MaskType1: 'AAAAAA-999-999' };
// export const APIBaseAddress = 'http://usfkl23as155.mercer.com:7877/cclman_ords/mfswwc1d/cclman/';
export const WebConfigFilePath = 'assets/app.config.json';
export let ApplicationSessionId: string;
