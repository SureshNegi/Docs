import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap, mergeMap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { EmployeeInfo } from '../models/common.models';
import { APINames } from './api-url.config';
import { Observable, of, from, throwError } from 'rxjs';
import { delay } from 'rxjs/internal/operators';
import { concatMap } from 'rxjs/internal/operators';
import * as ApiCoreTypes from './api-response.model';
import { CookieService } from 'ngx-cookie-service';
import { CoreService, UserAuthTokenDetail } from './core.service';

const apiParamPrefix = 'I_JSON';
import { LoaderService } from '../shared/loader.service';
import { EnumAPIResponseStatus } from './api-response.model';

@Injectable({
    providedIn: 'root'
})
export class AuthService {
    redirectUrl: string;
    constructor(private loaderService: LoaderService, private httpClient: HttpClient, private cookieService: CookieService) { }
    employeeLogin(uName, pass): Observable<ApiCoreTypes.IAPIResponse> {
        CoreService.COOKIES_SERVICE_OBJ = this.cookieService;
        const apiURL = `${environment.apiBaseURL}${APINames.empLogin}`;
        const paramObj = {
            username: uName, password: pass
        };
        return this.httpClient.post<ApiCoreTypes.IAPIResponse>(apiURL, paramObj).pipe(map(apiObj => {
            CoreService.COOKIES_SERVICE_OBJ = this.cookieService;
            return this.parseLoginAPIResponse(apiObj.data);
        }));

        // this.loaderService.isLoading.next(true);
        // const obj1 = { responseCode: 0, sessionId: 'abc', empInfo: { empNo: 1, displayName: 's' } };
        // const obj = this.parseLoginAPIResponse(obj1);
        // const fakeObservable = of(obj).pipe(delay(1000));
        // fakeObservable.subscribe(() => {
        //     this.loaderService.isLoading.next(false);
        // });
        // return fakeObservable;
    }
    errorHandler(error: any) {
        if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
        } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            console.error(
                `Backend returned code ${error.status}, ` +
                `body was: ${error.error}`);
        }
        const repObj: ApiCoreTypes.IAPIResponse = {} as ApiCoreTypes.IAPIResponse;
        return repObj;
    }
    testApi() {
        CoreService.COOKIES_SERVICE_OBJ = this.cookieService;
        const apiURL = `http://usfkl23as155.mercer.com:7877/cclman_ords/mfswwc1d/cclman/ords_test/employees/`;
        const headers = new HttpHeaders().set('Content-Type', 'application/json');
        return this.httpClient.post<ApiCoreTypes.IAPIResponse>(apiURL, { headers }).pipe(map(apiObj => {
            console.log(apiObj);
            return apiObj;
        }));
    }
    employeeLogout(uName): Observable<ApiCoreTypes.IAPIResponse> {
        const apiURL = `${environment.apiBaseURL}${APINames.empLogin}`;
        const paramObj = {
            emplNo: CoreService.getEmpNo()
        };
        const httpOptions = {
            headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: paramObj
        };
        return this.httpClient.delete<ApiCoreTypes.IAPIResponse>(apiURL, httpOptions).pipe(map(apiObj => {
            CoreService.clearUserSession();
            return apiObj;
        })
        );
    }
    parseLoginAPIResponse(apiObj: any): ApiCoreTypes.IAPIResponse {
        const repObj: ApiCoreTypes.LoginAPIResponse = { responseCode: apiObj.responseCode } as ApiCoreTypes.LoginAPIResponse;
        repObj.responseCode = +repObj.responseCode; // change to number in case api return string
        if (repObj.responseCode === ApiCoreTypes.EnumAPIResponseStatus.OK) {
            // const eInfo = { displayName: apiObj.empInfo[0].displayname, employeeNo: apiObj.empInfo[0].empno } as EmployeeInfo;
            repObj.data = { sessionId: apiObj.sessionId, empInfo: apiObj.empInfo };
            // tslint:disable-next-line:max-line-length
            CoreService.saveUserTokeninfo({ AuthToken: repObj.data.sessionId, LoginId: repObj.data.empInfo.empNo, DisplayEmpName: repObj.data.empInfo.displayName } as UserAuthTokenDetail);
        } else {
            repObj.responseMessage = apiObj.responseMessage;
        }
        return repObj;
    }
    parseLogoutAPIResponse(apiObj: any): ApiCoreTypes.IAPIResponse {
        const repObj: ApiCoreTypes.LoginAPIResponse = {} as ApiCoreTypes.LoginAPIResponse;
        // repObj.ResponseStatus = 4;
        // repObj.AckMessage = 'Invalid Login';
        // repObj.Data = { AuthToken: 'abcdefgh', LoginId: 1 } as UserAuthTokenDetail;
        return repObj;
    }
    isEmpLoggedIn() {
        // const tokenString = localStorage.getItem('userAuthTokenDetail');
        const tokenString = CoreService.getUserTokenInfo();
        const userDetail: UserAuthTokenDetail = tokenString ? JSON.parse(tokenString) : null;
        if (userDetail && userDetail.AuthToken && userDetail.LoginId) {
            return true;
        } else {
            return false;
        }
    }

}





