import { Injectable } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { AlertComponent } from '../shared/components/popups/alert-popup/alert.component';
import { CoreMessageService, EnumMessageType } from './core-message.service';
import { ConfirmPopupComponent } from '../shared/components/popups/confirm-popup/confirm-popup.component';


@Injectable({
    providedIn: 'root'
})
export class CoreAlertService {
    constructor(private modalService: NgbModal, private messageService: CoreMessageService) {
    }
    showAlertPopup(msgList) {
        const modalRef = this.modalService.open(AlertComponent, { centered: true, windowClass: 'message-popup alert-popup' });
        modalRef.componentInstance['msgList'] = msgList;
        return modalRef;
    }
    showConfirmPopup(title, options: NgbModalOptions, msgList?) {
        const modalRef = this.modalService.open(ConfirmPopupComponent, { centered: true, windowClass: options.windowClass });
        modalRef.componentInstance['msgList'] = msgList;
        modalRef.componentInstance['title'] = title;
        return modalRef;
    }
    showDynamicPopupWindow<T>(component: T, options: NgbModalOptions, inputParam: any): NgbModalRef<T> {
        const modalRef = this.modalService.open(component, { centered: true, windowClass: options.windowClass });
        modalRef.componentInstance['data'] = inputParam;
        return modalRef;
    }
    showSucessToasMessage(msg: string) {
        this.messageService.sendMessage(msg, EnumMessageType.SucessToastMessage);
    }
}



