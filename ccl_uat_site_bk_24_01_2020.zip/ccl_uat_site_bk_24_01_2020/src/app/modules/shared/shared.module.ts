import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { LoaderInterceptor } from '../core/loader.interceptor';
import { ToastModule } from 'primeng/toast';
// import { NgbModule, NgbDropdownModule, NgbTooltipModule, NgbModalModule, NgbTabsetModule } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmPopupComponent } from './components/popups/confirm-popup/confirm-popup.component';
import { HTTP_INTERCEPTORS, HttpClient, HttpClientModule } from '@angular/common/http';
import { LoaderService } from './loader.service';
import { LoaderComponent } from './components/loaders/loaders.component';
import { AlertComponent } from './components/popups/alert-popup/alert.component';
import { NotificationProviderComponent } from './components/notification/notification.component';

@NgModule({
  declarations: [LoaderComponent, ConfirmPopupComponent, AlertComponent, NotificationProviderComponent],
  imports: [
    // tslint:disable-next-line:max-line-length
    FormsModule, CommonModule, ReactiveFormsModule, ToastModule
  ], exports: [NotificationProviderComponent, FormsModule, ReactiveFormsModule, LoaderComponent, ConfirmPopupComponent]
  , entryComponents: [ConfirmPopupComponent, AlertComponent],
  providers: [LoaderService, { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }]

})
export class SharedModule { }
