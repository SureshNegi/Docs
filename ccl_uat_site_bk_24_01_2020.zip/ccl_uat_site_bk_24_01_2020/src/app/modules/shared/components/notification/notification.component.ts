import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { MessageService } from 'primeng/api';
import { CoreMessageService, EnumMessageType, MessageObj } from '../../../core/core-message.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
  providers: [MessageService]
})
export class NotificationProviderComponent implements OnDestroy, OnInit {
  subscription: Subscription;
  constructor(private pngMssageService: MessageService, private messageService: CoreMessageService) {
    this.subscription = this.messageService.getMessage().subscribe((message: MessageObj) => {
      if (message.Type === EnumMessageType.SucessToastMessage) {
        this.showSucessToastMessage(message.Message);
      }
    });
  }
  ngOnInit() {
  }
  showSucessToastMessage(message) {
    this.pngMssageService.add({ summary: message, severity: 'success', sticky: false, life: 200000 });
  }
  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }

}
