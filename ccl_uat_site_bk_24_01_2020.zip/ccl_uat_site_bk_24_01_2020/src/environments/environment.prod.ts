export const environment = {
  production: true,
  apiBaseURL: '',
  appVersion: '1.0',
  appTitile: 'CCL_UAT_SITE HTML5v1.0 (DEV - usfkl23as155)'
};
